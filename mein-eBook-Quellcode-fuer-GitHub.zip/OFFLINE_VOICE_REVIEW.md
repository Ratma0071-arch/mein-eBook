# Offline-Stimmenprüfung – 23.11.2026

Basis: App 2.6, sherpa-onnx 1.12.17 und die eigene deutsche KittenSpeech-Integration.
Alle Bewertungen betreffen lokale Inferenz nach einem ausdrücklich gestarteten Modell-Download. Es wurden nur öffentliche Modellkarten und Dokumentation abgerufen; keine privaten Texte wurden übertragen.

| Kandidat | Sprachen | Lizenz und Speicher | Qualität / Android-Entscheidung |
|---|---|---|---|
| KittenML KittenTTS 2 Mini | Deutsch, Englisch, Französisch, Italienisch, Spanisch (und weitere) | Modellkarte: Apache-2.0; 82,7 MB int8 oder 47,5 MB int4 für das Modell, zusätzlich Stimmvektoren, Frontend und Laufzeit | 24 kHz, mehrere Stimmen. Natürlichkeit nicht in diesem Lauf hörend geprüft. CPU-ONNX; vorhandenes JNI ist deutsch festgelegt. Andere Sprachen erfordern geprüftes Frontend und passende Vektoren. Kein bloßer Katalogeintrag. Int4 benötigt ONNX Runtime >=1.20. |
| Piper Cori medium | Englisch (GB) | Ältere Modellkarte: Public-Domain-Datensatz. Aktuelle Nachtrainierungen können andere Zuschreibungen und Piper >=1.5 verlangen. | 22,05 kHz, medium. Vor einer Ergänzung genau die konvertierte sherpa-Paketversion, Lizenz, Größe und SHA256 prüfen; keine neue Tonprobe geprüft. |
| Piper MLS medium | Französisch | CC-BY 4.0, 76,7 MB ONNX laut offiziellem Dateibaum, dazu Daten | 125 Sprecher, 22,05 kHz. Sprecher-ID und Stimme dürfen nicht zufällig als männlich/weiblich etikettiert werden. Android-Paket muss einzeln getestet werden. |
| Piper Paola medium (aktuell) | Italienisch | CC0-Datensatz; aktuelle Karte verlangt Piper >=1.5. Konkrete neue Paketgröße nicht verifiziert. | 22,05 kHz. Bereits vorhandene ältere Paola-Version bleibt gepinnt. Neue Gewichte nicht mit alter Laufzeit gleichsetzen. |
| Piper Davefx medium (aktuell) | Spanisch | CC0-Datensatz; aktuelle Karte verlangt Piper >=1.5. Offizieller Dateibaum: ca. 63,2 MB ONNX plus Daten. | 22,05 kHz. Erst sherpa-Konvertierung, Lizenzdateien und Android-Ausgabe prüfen. |
| Kokoro | Englisch; andere Sprachen je Frontend | Apache-2.0; sherpa-Beispiel v1.0 ca. 310 MB ONNX plus 26 MB Stimmen und Wörterbücher | sherpa bietet Android-APKs; dokumentiertes mehrsprachiges Frontend dort nur Englisch/Chinesisch. Deshalb derzeit kein Ersatz für alle fünf Zielsprachen. |

Die Qualitätsstufen sind Herstellerangaben, kein eigener Hörvergleich. Code-Lizenzen gelten nicht automatisch für Modellgewichte. Keine Emotionssteuerung oder Trainingsfähigkeit wird aus einer Modellbezeichnung abgeleitet.

## Offizielle Quellen

- https://huggingface.co/KittenML/kitten-tts-2-mini (abgerufene Revision 8e89ae2a718ee4bb893c67d67657e520e6112faf)
- https://github.com/KittenML/KittenTTS (Code und Gewichte ausdrücklich getrennt lizenziert)
- https://huggingface.co/rhasspy/piper-voices/blob/main/en/en_GB/cori/medium/MODEL_CARD
- https://huggingface.co/rhasspy/piper-voices/blob/main/fr/fr_FR/mls/medium/MODEL_CARD
- https://huggingface.co/rhasspy/piper-voices/blob/main/it/it_IT/paola/medium/MODEL_CARD
- https://huggingface.co/rhasspy/piper-voices/blob/main/es/es_ES/davefx/medium/MODEL_CARD
- https://k2-fsa.github.io/sherpa/onnx/tts/pretrained_models/kokoro.html
- https://k2-fsa.github.io/sherpa/onnx/tts/apk-engine.html

Nächster sinnvoller Schritt: Kitten-Mini-Frontend für eine weitere Sprache isoliert prototypisieren, Modell/Vektoren pinnen, öffentliche neutrale Sprachproben lokal erzeugen, Aussetzer und Leistung auf Android messen und erst danach einen Katalogeintrag veröffentlichen.
