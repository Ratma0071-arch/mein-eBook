# Entwicklungsstand

Stand: Version 2.6, versionCode 8.

## In diesem Lauf umgesetzt

- Durchsuchbares Figurenverzeichnis; die Suche ignoriert Groß-/Kleinschreibung und Akzente und durchsucht Namen, zugewiesene Stimmen und Sprache.
- Gemeinsame lokale JSON-Sicherung für eigene Figuren, Stimmenprofile, Figuren-Stimmen, manuelle Dialogkorrekturen und Kapitel-Erzähler.
- Sicherungsdateien enthalten ausdrücklich keine Buchtexte, importierten EPUB/TXT/HTML-Dateien oder Audiodaten.
- Wiederherstellung prüft Dateigröße, Format, Figuren, Einstellungsgrenzen, Sprecher-IDs und Kapitelkennungen vollständig vor dem ersten Schreibzugriff. Gültige Einträge werden ergänzt; bestehende lokale Daten werden nicht pauschal ersetzt.

- Beständiges Figurenverzeichnis mit Stimmenstatus für André, Mike, René, Michael, Thomas, Brigitte, Lothar, Andrea Schwarz, Margarete Schwarz, Wolfgang und Maria Gärtner, Giovanni, Marco, Mia, Miguel, Nicole, Johannes, Luca, Alessandro, Fabio und Luciano.
- Manuelle Sprecherkorrektur direkt an erkannten und unklaren Dialogstellen. Jede Korrektur kann auf automatische Erkennung zurückgesetzt werden.
- Kapitelweise Erzählerwahl: Standard-Erzählerprofil, André oder Mike. Die Auswahl ist an den Kapiteltext gebunden und bleibt lokal gespeichert.
- Familiennamen werden regelbasiert zusätzlich zu Vornamen erkannt. Unklare Rede bleibt beim Erzähler; es gibt weiterhin keine zufällige Sprecherverteilung.
- Verstellbares, großes Lesefenster (18–42 px, 45–85 % Bildschirmhöhe) mit lokaler Speicherung.
- Dauerhafte Hervorhebung der aktuellen Textstelle, auch nach Pause oder manuellem Sprung.
- Lokales IndexedDB-Bücherregal für EPUB, TXT und HTML. Rohdateien verlassen das Gerät nicht; jedes Regalbuch erhält einen stabilen Schlüssel und getrennte Kapitelpositionen.
- Separates Textlabor für kurze Stimmproben mit der aktuell gewählten lokalen Stimme.
- Begrenzte lokale Rückgängig-Historie für Textänderungen. Die vorhandene Bereinigung bleibt absichtlich auf Leerzeichen und einfache Satzzeichen beschränkt; es wird keine umfassende Grammatikprüfung behauptet.

## Geprüft

- Vorhandener Node-Integrationstest: fünf Sprachen, Stimmenprofile, Dialogzuordnung, Textbereinigung, MP3-Plan und native Lesewarteschlange.
- Neuer DOM-Test: Leseregler, Markierungs-Hooks, Textlabor, Bücherregal-Oberfläche und stabile Buch-IDs.
- Neue Integrationstests: vollständiger Figurenbestand, Familiennamen, reversible manuelle Sprecherkorrektur, kapitelweise Erzählerwahl und Übergabe der korrigierten Rolle an die native Lesewarteschlange.
- JavaScript-Syntaxprüfung und Quellinvarianten für Sicherungsumfang, Größenlimit und Prüfung vor dem ersten Schreibzugriff. Der vollständige Android-WebView-Test erfolgt im GitHub-CI-Lauf.
- Android-CI muss nach dem GitHub-Commit erneut vollständig laufen (assembleDebug und verbundene Gerätests).

## Einschränkungen / nächste Schritte

- IndexedDB wird erst im echten Android-WebView vollständig geprüft; bei nicht verfügbarem Speicher zeigt die App eine lokale Fehlermeldung und der normale Dateiimport bleibt nutzbar.
- Die Sicherung wird als normale JSON-Datei über die Android-Dateiauswahl gespeichert bzw. eingelesen; der Dateidialog bleibt eine bewusste Nutzeraktion.
- Offizielle sherpa-onnx-Unterlagen listen inzwischen weitere Android-TTS-Modelle, darunter Kokoro für Englisch/Chinesisch und Supertonic-3-Engine-Pakete. Sie wurden nicht eingebaut: Das Projekt verwendet die geprüfte sherpa-onnx-Version 1.12.17, während die aktuellen Pakete mit 2.0.1 veröffentlicht sind. Ein Bibliothekswechsel benötigt eigene Qualitäts-, Lizenz-, Offline- und Geräteprüfungen und wird nicht als bloßer Stimmen-Download ausgegeben.
- Keine Cloud-Grammatik, keine Telemetrie, kein Training oder Klonen von Stimmen.
