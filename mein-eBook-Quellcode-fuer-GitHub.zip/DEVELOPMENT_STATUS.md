# Entwicklungsstand

Stand: Version 2.7, versionCode 9. Prüfung vom 23.11.2026, Ausgangspunkt 30bcb7d14d2436d3a5d96319446526eb95b2b2f9.

## Fehlerbehebung 2.7

- Dialogkorrekturen werden als hash:Textlänge:Abschnitt gespeichert. Der Import akzeptiert jetzt dieses echte Format; 2.6 lehnte es wegen eines fehlenden Kennungsbestandteils ab.
- Stimmenprofile mit der in der Oberfläche zulässigen Tonhöhe 1,55 lassen sich wieder importieren.
- Figuren-Sicherungen verwenden in Android einen eigenen ACTION_CREATE_DOCUMENT-Dialog mit application/json. Erfolg wird erst nach dem Schreiben gemeldet; Abbruch meldet keinen Erfolg. Die Speicherung nutzt getrennte Daten und Rückmeldungen von der Buchdatei-Speicherung.
- Neuer CharacterBackupTest prüft im echten Android-WebView den Import real erzeugter Dialogkennungen und maximaler Tonhöhe sowie den Android-JSON-Speicherdialog. Der Dateischreibvorgang mit einem konkreten Dokumentanbieter bleibt ein Gerätetest.
- Stimmenrecherche und bewusst zurückgestellte Kandidaten: OFFLINE_VOICE_REVIEW.md. Kein ungeprüftes Modell in den Downloadkatalog aufgenommen.

## In diesem Lauf umgesetzt

- Durchsuchbares Figurenverzeichnis; die Suche ignoriert Groß-/Kleinschreibung und Akzente und durchsucht Namen, zugewiesene Stimmen und Sprache.
- Gemeinsame lokale JSON-Sicherung für eigene Figuren, Stimmenprofile, Figuren-Stimmen, manuelle Dialogkorrekturen und Kapitel-Erzähler.
- Sicherungsdateien enthalten ausdrücklich keine Buchtexte, importierten EPUB/TXT/HTML-Dateien oder Audiodaten.
- Wiederherstellung prüft Dateigröße, Format, Figuren, Einstellungsgrenzen, Sprecher-IDs und Kapitelkennungen vollständig vor dem ersten Schreibzugriff. Gültige Einträge werden ergänzt; bestehende lokale Daten werden nicht pauschal ersetzt.

- Beständiges Figurenverzeichnis mit Stimmenstatus für André, Mike, René, Michael, Thomas, Brigitte, Lothar, Andrea Schwarz, Margarete Schwarz, Wolfgang und Maria Gärtner, Giovanni, Marco, Mia, Miguel, Nicole, Johannes, Luca, Alessandro, Fabio und Luciano.
- Manuelle Sprecherkorrektur direkt an erkannten und unklaren Dialogstellen. Jede Korrektur kann auf automatische Erkennung zurückgesetzt werden.
- Kapitelweise Erzählerwahl: Standard-Erzählerprofil, André oder Mike. Die Auswahl ist an den Kapiteltext gebunden und bleibt lokal gespeichert.
- Familiennamen werden regelbasiert zusätzlich zu Vornamen erkannt. Unklare Rede bleibt beim Erzähler; es gibt weiterhin keine zufällige Sprecherverteilung.
- Verstellbares, großes Lesefenster (18–42 px, 45–85 % Bildschirmhöhe) mit lokaler Speicherung.
- Dauerhafte Hervorhebung der aktuellen Textstelle, auch nach Pause oder manuellem Sprung.
- Lokales IndexedDB-Bücherregal für EPUB, TXT und HTML. Rohdateien verlassen das Gerät nicht; jedes Regalbuch erhält einen stabilen Schlüssel und getrennte Kapitelpositionen.
- Separates Textlabor für kurze Stimmproben mit der aktuell gewählten lokalen Stimme.
- Begrenzte lokale Rückgängig-Historie für Textänderungen. Die vorhandene Bereinigung bleibt absichtlich auf Leerzeichen und einfache Satzzeichen beschränkt; es wird keine umfassende Grammatikprüfung behauptet.

## Geprüft

- Vorhandener Node-Integrationstest: fünf Sprachen, Stimmenprofile, Dialogzuordnung, Textbereinigung, MP3-Plan und native Lesewarteschlange.
- Neuer DOM-Test: Leseregler, Markierungs-Hooks, Textlabor, Bücherregal-Oberfläche und stabile Buch-IDs.
- Neue Integrationstests: vollständiger Figurenbestand, Familiennamen, reversible manuelle Sprecherkorrektur, kapitelweise Erzählerwahl und Übergabe der korrigierten Rolle an die native Lesewarteschlange.
- JavaScript-Syntaxprüfung und Quellinvarianten für Sicherungsumfang, Größenlimit und Prüfung vor dem ersten Schreibzugriff. Der vollständige Android-WebView-Test erfolgt im GitHub-CI-Lauf.
- Android-CI muss nach dem GitHub-Commit erneut vollständig laufen (assembleDebug und verbundene Gerätests).

## Einschränkungen / nächste Schritte

- IndexedDB wird erst im echten Android-WebView vollständig geprüft; bei nicht verfügbarem Speicher zeigt die App eine lokale Fehlermeldung und der normale Dateiimport bleibt nutzbar.
- Sicherungen werden ab 2.7 über einen eigenen Android-JSON-Speicherdialog angeboten; das vollständige Schreiben/Einlesen über verschiedene Dokumentanbieter braucht zusätzliche Gerätetests.
- Offizielle sherpa-onnx-Unterlagen listen inzwischen weitere Android-TTS-Modelle, darunter Kokoro für Englisch/Chinesisch und Supertonic-3-Engine-Pakete. Sie wurden nicht eingebaut: Das Projekt verwendet die geprüfte sherpa-onnx-Version 1.12.17, während die aktuellen Pakete mit 2.0.1 veröffentlicht sind. Ein Bibliothekswechsel benötigt eigene Qualitäts-, Lizenz-, Offline- und Geräteprüfungen und wird nicht als bloßer Stimmen-Download ausgegeben.
- Keine Cloud-Grammatik, keine Telemetrie, kein Training oder Klonen von Stimmen.
