# Entwicklungsstand

Stand: Version 2.4, versionCode 6.

## In diesem Lauf umgesetzt

- Verstellbares, großes Lesefenster (18–42 px, 45–85 % Bildschirmhöhe) mit lokaler Speicherung.
- Dauerhafte Hervorhebung der aktuellen Textstelle, auch nach Pause oder manuellem Sprung.
- Lokales IndexedDB-Bücherregal für EPUB, TXT und HTML. Rohdateien verlassen das Gerät nicht; jedes Regalbuch erhält einen stabilen Schlüssel und getrennte Kapitelpositionen.
- Separates Textlabor für kurze Stimmproben mit der aktuell gewählten lokalen Stimme.
- Begrenzte lokale Rückgängig-Historie für Textänderungen. Die vorhandene Bereinigung bleibt absichtlich auf Leerzeichen und einfache Satzzeichen beschränkt; es wird keine umfassende Grammatikprüfung behauptet.

## Geprüft

- Vorhandener Node-Integrationstest: fünf Sprachen, Stimmenprofile, Dialogzuordnung, Textbereinigung, MP3-Plan und native Lesewarteschlange.
- Neuer DOM-Test: Leseregler, Markierungs-Hooks, Textlabor, Bücherregal-Oberfläche und stabile Buch-IDs.
- Android-CI muss nach dem GitHub-Commit erneut vollständig laufen (assembleDebug und verbundene Gerätests).

## Einschränkungen / nächste Schritte

- IndexedDB wird erst im echten Android-WebView vollständig geprüft; bei nicht verfügbarem Speicher zeigt die App eine lokale Fehlermeldung und der normale Dateiimport bleibt nutzbar.
- Die manuelle Korrektur unklarer Dialogsprecher und eine komfortablere Figurenverwaltung bleiben die nächste größere Ausbaustufe.
- Keine Cloud-Grammatik, keine Telemetrie, kein Training oder Klonen von Stimmen.
