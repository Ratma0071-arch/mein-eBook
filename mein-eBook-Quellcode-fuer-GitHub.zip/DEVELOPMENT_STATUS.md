# Entwicklungsstand

Stand: Version 2.5, versionCode 7.

## In diesem Lauf umgesetzt

- Beständiges Figurenverzeichnis mit Stimmenstatus für André, Mike, René, Michael, Thomas, Brigitte, Lothar, Andrea Schwarz, Margarete Schwarz, Wolfgang und Maria Gärtner, Giovanni, Marco, Mia, Miguel, Nicole, Johannes, Luca, Alessandro, Fabio und Luciano.
- Manuelle Sprecherkorrektur direkt an erkannten und unklaren Dialogstellen. Jede Korrektur kann auf automatische Erkennung zurückgesetzt werden.
- Kapitelweise Erzählerwahl: Standard-Erzählerprofil, André oder Mike. Die Auswahl ist an den Kapiteltext gebunden und bleibt lokal gespeichert.
- Familiennamen werden regelbasiert zusätzlich zu Vornamen erkannt. Unklare Rede bleibt beim Erzähler; es gibt weiterhin keine zufällige Sprecherverteilung.
- Verstellbares, großes Lesefenster (18–42 px, 45–85 % Bildschirmhöhe) mit lokaler Speicherung.
- Dauerhafte Hervorhebung der aktuellen Textstelle, auch nach Pause oder manuellem Sprung.
- Lokales IndexedDB-Bücherregal für EPUB, TXT und HTML. Rohdateien verlassen das Gerät nicht; jedes Regalbuch erhält einen stabilen Schlüssel und getrennte Kapitelpositionen.
- Separates Textlabor für kurze Stimmproben mit der aktuell gewählten lokalen Stimme.
- Begrenzte lokale Rückgängig-Historie für Textänderungen. Die vorhandene Bereinigung bleibt absichtlich auf Leerzeichen und einfache Satzzeichen beschränkt; es wird keine umfassende Grammatikprüfung behauptet.

## Geprüft

- Vorhandener Node-Integrationstest: fünf Sprachen, Stimmenprofile, Dialogzuordnung, Textbereinigung, MP3-Plan und native Lesewarteschlange.
- Neuer DOM-Test: Leseregler, Markierungs-Hooks, Textlabor, Bücherregal-Oberfläche und stabile Buch-IDs.
- Neue Integrationstests: vollständiger Figurenbestand, Familiennamen, reversible manuelle Sprecherkorrektur, kapitelweise Erzählerwahl und Übergabe der korrigierten Rolle an die native Lesewarteschlange.
- Android-CI muss nach dem GitHub-Commit erneut vollständig laufen (assembleDebug und verbundene Gerätests).

## Einschränkungen / nächste Schritte

- IndexedDB wird erst im echten Android-WebView vollständig geprüft; bei nicht verfügbarem Speicher zeigt die App eine lokale Fehlermeldung und der normale Dateiimport bleibt nutzbar.
- Als nächste Ausbaustufe eignen sich ein Suchfeld im Figurenverzeichnis und eine optionale Sicherung der Sprecherkorrekturen zusammen mit den Stimmenprofilen.
- Keine Cloud-Grammatik, keine Telemetrie, kein Training oder Klonen von Stimmen.
