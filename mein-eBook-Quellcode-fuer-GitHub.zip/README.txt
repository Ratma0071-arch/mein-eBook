mein eBook – Android-Projekt (Quellcode)

Dies ist KEINE fertige APK. Ohne Android SDK/Gradle konnte hier keine APK gebaut oder auf einem Android-Gerät getestet werden.

So erstellst du eine installierbare APK:
1. Projektordner in Android Studio (aktuelle Version) öffnen.
2. Gradle-Synchronisierung abwarten; Internet ist nur für das EINMALIGE Herunterladen der Android-Bauwerkzeuge/Plugins erforderlich.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK liegt unter app/build/outputs/apk/debug/app-debug.apk.
5. Auf Android installieren (Installation aus dieser Quelle ggf. erlauben).

App-Funktionen: EPUB/TXT/HTML öffnen, lokal bearbeiten, EPUB wieder speichern, bei Schreibfreigabe Originaldatei überschreiben, native Android TTS-Sprachausgabe und Stimmenprofile. Die App selbst hat KEINE Internet-Berechtigung. Keine echten lokal neuronalen KI-Stimmen, kein Stimmenklonen. DRM-Bücher werden nicht unterstützt.

WICHTIG: Sprachsynthese hängt von der auf Android installierten OFFLINE-TTS-Engine ab. Pause ist je nach Engine ein Stop/Neustart des laufenden Satzes. Das Projekt wurde in dieser Umgebung nicht kompiliert oder auf einem Gerät getestet.

ALTERNATIVE OHNE ANDROID STUDIO (GitHub Actions):
Projekt-Dateien in ein eigenes GitHub-Repository hochladen (inklusive .github/workflows/android-apk.yml).
Im Tab Actions den Workflow „Android APK bauen“ starten (oder per Push auf main/master auslösen).
Nach erfolgreichem Build unter Artifacts „mein-eBook-installierbare-APK“ herunterladen,
ZIP entpacken und app-debug.apk auf Android installieren.
Hinweis: Hier liegt der Quellcode, keine fertige APK. Der CI-Build wurde nicht ausgeführt oder getestet.
