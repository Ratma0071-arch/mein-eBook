mein eBook 2.1 – lokale KI-Stimmen und MP3

Funktionen:
- Deutsch, Englisch, Französisch, Italienisch, Spanisch; keine Übersetzung.
- Lokale Piper/VITS-KI-Stimmen über sherpa-onnx. Einzelne Stimmenpakete werden ausdrücklich per Button heruntergeladen und per SHA-256 geprüft. Buchtexte werden nicht übertragen.
- Männliche/weibliche Basisstimmen; eigene Profile für André, Mike, René, Michael und Thomas. Stimmalter/Charakter sind Annäherungen durch Parameter, keine Klone oder semantische Schauspiel-KI.
- Automatischer Sprecherwechsel für markierte Absätze wie „André: Hallo.“. Keine zuverlässige automatische Erkennung freier literarischer Dialoge.
- MP3-Export eines Kapitels oder ganzen Buches (Mono 64 kbit/s), Fortschritt/Abbruch; App offen halten. Gerätestimmen müssen PCM16-WAV liefern.
- Startbildschirm-Verknüpfung nach Android-Bestätigung.

Bauen: Java 17, Gradle 8.10.2, Android SDK 35, NDK 27.2.12479018, CMake 3.22.1.
Gradle lädt die offizielle gepinnte sherpa-onnx-AAR mit SHA-256-Prüfung. Bibliothek 1.12.17, https://github.com/k2-fsa/sherpa-onnx
LAME-Quelle (LGPL) aus https://github.com/lameproject/lame Commit 1f5cc9487284d5950343aa5d4f70de433468070a liegt unter app/src/main/cpp/lame. JNI-Wrapper und Änderungen liegen im Quellarchiv. Die LGPL erlaubt den Austausch der Bibliothek; die App ist ein offenes, neu baubares Debug-Projekt.

Das enthaltene debug.keystore ist ausschließlich ein öffentlicher Entwicklungs-Testschlüssel (Passwort android), kein geheimer Produktionsschlüssel. Er sorgt für installierbare spätere Test-Updates. Die Version 1.0 verwendete einen anderen flüchtigen Testschlüssel; ggf. müssen Einstellungen exportiert und die alte App einmal deinstalliert werden.

Modelle/Karten: https://github.com/k2-fsa/sherpa-onnx/releases/tag/tts-models
Alle Pakete einschließlich MODEL_CARD und Konfiguration bleiben lokal im App-Speicher. Lizenztexte unter assets/licenses. Texte und Bücher werden nicht mitgeliefert.

Version 2.1: neue Bereiche Lesen/Text/Stimmen/MP3/Updates, größere Darstellung, manuelle Texte mit lokalem Entwurf, Live-Übernahme und konservative lokale Korrektur von Abständen/Satzzeichen (keine KI-Grammatikprüfung). Update-Prüfung liest öffentliche GitHub-Releases; Installation bleibt eine ausdrückliche Android-Bestätigung.

Version 2.2: Nativer Medien-Vordergrunddienst mit eigener Lesewarteschlange, MediaSession, Sperrbildschirm-Steuerung, Audiofokus und zeitlich begrenztem CPU-WakeLock. Automatische Dialogzuordnung anhand expliziter Namen/Redebegleitsätze und regelbasierte Ausdruckshinweise; unklare Dialoge bleiben Erzähler. Weibliche/männliche Basisstimmen, eigene Sprecher mit Altersklang-Annäherung, Download beider Stimmen einer Sprache. Keine automatische Modell-Nachschulung und kein vollständiges literarisches Verständnis. Emulator-Test ScreenOffReadingTest prüft neuronale Wiedergabe und Satzfortschritt bei ausgeschaltetem Bildschirm.

Version 2.5: Figurenverzeichnis und manuelle Dialogkorrektur
--------------------------------------------------------------------------
- Beständiges Figurenverzeichnis mit allen Haupt- und Nebenfiguren sowie der jeweils zugewiesenen lokalen Stimme.
- Erkannte oder unklare wörtliche Rede kann direkt an der Textstelle einer Figur oder bewusst dem Erzähler zugeordnet werden.
- Manuelle Sprecherkorrekturen sind lokal gespeichert, zurücksetzbar und an den unveränderten Kapiteltext gebunden.
- André, Mike oder das gespeicherte Erzählerprofil können kapitelweise als Erzähler gewählt werden.
- Familiennamen Andrea Schwarz, Margarete Schwarz, Wolfgang Gärtner und Maria Gärtner werden zusätzlich zu den Vornamen erkannt.
- Unklare Dialoge werden weiterhin nicht zufällig verteilt. Ohne eindeutige oder manuelle Zuordnung bleibt die Erzählerstimme aktiv.

Version 2.6: Figuren-Suche und lokale Sicherung
------------------------------------------------
- Das Figurenverzeichnis lässt sich nach Name, zugewiesener Stimme oder Sprache durchsuchen; Akzente und Großschreibung beeinflussen die Suche nicht.
- Figuren, Stimmenprofile, Stimmenzuordnungen, manuelle Dialogkorrekturen und Kapitel-Erzähler lassen sich gemeinsam als JSON sichern und wieder einlesen.
- Buchtexte, Regaldateien und Audiodaten sind nicht Bestandteil dieser Sicherung.
- Der Import wird vollständig geprüft und ergänzt gültige Daten, ohne bestehende Einstellungen ungefragt zu löschen.

Version 2.4: Lokales Bücherregal, verstellbares Lesefenster und Textlabor
--------------------------------------------------------------------------
- Mehrere EPUB/TXT/HTML-Dateien bleiben im lokalen IndexedDB-Speicher der App.
- Lesepositionen werden pro Regalbuch getrennt gesichert; Bücher lassen sich einzeln entfernen.
- Textgröße (18–42 px) und Lesefensterhöhe sind verstellbar und bleiben gespeichert.
- Die aktuelle Textstelle bleibt auch im Pausenmodus sichtbar hervorgehoben.
- Das Textlabor liest kurze Proben mit der gewählten lokalen Stimme, ohne den Buchtext zu ändern.
- Textänderungen lassen sich schrittweise rückgängig machen. Die automatische Bereinigung bleibt bewusst konservativ und verändert keine Füllwörter.

Version 2.3: Deutsches Studio-Stimmenpaket (KittenTTS 2 Mini)
- Neue native ONNX-Integration, 13 deutsche Stimmen, einmaliger gemeinsamer Download.
- Vollständig lokal; keine Analyse- oder Telemetrieübertragung.
- Stimmen basieren auf KittenML/kitten-tts-2-mini, Revision c01797caec3967b400da457656e011eb81f530a4.
- Dies ist die kompakte Modellfamilie, nicht das größere KittenTTS-2-Modell mit Emotions-Tags. Gefühle/Altersprofile bleiben Annäherungen.
- Studio verwendet natürliche Grundtonhöhe, ohne automatische Kinder-/Jugend-Pitchverschiebung. Männliche/weibliche Dialogstimmen bleiben in derselben Modellfamilie.
- In der App unter Stimmen zum Beispiel Studio Lena, Studio Greta, Studio Jonas oder Studio Felix wählen und herunterladen. Mit einem Download werden alle 13 Stimmen verfügbar.
- APK behält die Entwicklungssignatur von Version 2.1/2.2.

Drittanbieter: KittenML Apache-2.0; ONNX Runtime MIT; eSpeak-ng GPL-3.0-or-later (Quellen: https://github.com/espeak-ng/espeak-ng, https://github.com/k2-fsa/sherpa-onnx). Die eSpeak-Daten stammen unverändert aus dem bereits verwendeten Piper-Paket. Die Stimmvektoren wurden ohne Veränderung der Werte von NPZ in Float32-Dateien umverpackt. Lizenzdateien und Herkunft liegen im Stimmenpaket.

Vorlesen 2.3 berechnet während laufender neuronaler Wiedergabe genau einen folgenden PCM-Abschnitt vor. Die Warteschlange bleibt vollständig nativ; Pause, Sprung, Buchwechsel und Dienstende prüfen weiterhin die Wiedergabe-Generation. MP3-Export verwendet dieselbe lokale Spracherzeugung.
