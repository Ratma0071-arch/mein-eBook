package de.meinebook.app;

import android.app.Instrumentation;
import android.content.Intent;
import android.webkit.WebView;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.json.JSONObject;
import java.lang.reflect.Field;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import static org.junit.Assert.*;

/** Synthetic settings only: exercises the actual WebView import and Android save intent. */
@RunWith(AndroidJUnit4.class)
public class CharacterBackupTest {
 private String eval(Instrumentation inst,WebView web,String script)throws Exception {
  CompletableFuture<String> result=new CompletableFuture<>();
  inst.runOnMainSync(()->web.evaluateJavascript(script,result::complete));
  return result.get(15,TimeUnit.SECONDS);
 }
 @Test public void restoresRealDialogueKeysAndOpensJsonSaveDialog()throws Exception {
  Instrumentation inst=InstrumentationRegistry.getInstrumentation();
  MainActivity activity=(MainActivity)inst.startActivitySync(new Intent(inst.getTargetContext(),MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
  Field f=MainActivity.class.getDeclaredField("web");f.setAccessible(true);WebView web=(WebView)f.get(activity);
  try {
   boolean ready=false;for(int i=0;i<100;i++){if("true".equals(eval(inst,web,"!!window.CharacterTools"))){ready=true;break;}Thread.sleep(100);}assertTrue("WebView ready",ready);
   // The real parser creates hash:length:index keys, not hash:length keys.
   String setup="(()=>{window.__backupBefore={};for(const k of ['meinebook.people.v1','lesestimme.voiceprofiles.v1','meinebook.studio.v2','meinebook.dialogue.overrides.v1','meinebook.chapterNarrators.v1'])__backupBefore[k]=localStorage.getItem(k);const p=DialogueParser;const items=p.split('André sagte: „Guten Morgen.“');const chapter=items[0].chapterKey;p.setSpeaker(0,'mike',chapter);p.setNarrator(chapter,'andre');window.__backupData={format:'meinebook-character-backup-v1',people:[],profiles:{Test:{voice:'neural:test',rate:1,pitch:1.55,volume:1}},cast:{},dialogueOverrides:JSON.parse(localStorage.getItem('meinebook.dialogue.overrides.v1')),chapterNarrators:JSON.parse(localStorage.getItem('meinebook.chapterNarrators.v1'))};localStorage.setItem('meinebook.dialogue.overrides.v1','{}');localStorage.setItem('meinebook.chapterNarrators.v1','{}');window.__backupImportDone=false;document.getElementById('characterBackupFile').onchange({target:{files:[{size:1000,text:async()=>JSON.stringify(__backupData)}],value:''}}).then(()=>{window.__backupImportDone=true});return true})()";
   assertEquals("true",eval(inst,web,setup));
   for(int i=0;i<30;i++){if("true".equals(eval(inst,web,"!!window.__backupImportDone")))break;Thread.sleep(10);}
   assertEquals("true",eval(inst,web,"(()=>{const p=JSON.parse(localStorage.getItem('lesestimme.voiceprofiles.v1'));const o=JSON.parse(localStorage.getItem('meinebook.dialogue.overrides.v1'));const n=JSON.parse(localStorage.getItem('meinebook.chapterNarrators.v1'));return p.Test.pitch===1.55&&Object.keys(__backupData.dialogueOverrides).every(k=>o[k]===__backupData.dialogueOverrides[k])&&Object.keys(__backupData.chapterNarrators).every(k=>n[k]===__backupData.chapterNarrators[k])})()"));
   // Restore before the import's delayed page reload; the test never retains synthetic settings.
   eval(inst,web,"(()=>{for(const [k,v] of Object.entries(__backupBefore))v===null?localStorage.removeItem(k):localStorage.setItem(k,v);return true})()");
   CompletableFuture<Intent> captured=new CompletableFuture<>();
   Instrumentation.ActivityMonitor monitor=new Instrumentation.ActivityMonitor(){@Override public Instrumentation.ActivityResult onStartActivity(Intent intent){if(Intent.ACTION_CREATE_DOCUMENT.equals(intent.getAction())){captured.complete(intent);return new Instrumentation.ActivityResult(MainActivity.RESULT_CANCELED,null);}return null;}};
   inst.addMonitor(monitor);
   try{activity.new Bridge().saveSettings("{\"format\":\"meinebook-character-backup-v1\"}");Intent intent=captured.get(15,TimeUnit.SECONDS);assertEquals("application/json",intent.getType());assertEquals("meinebook-figuren-und-dialoge.json",intent.getStringExtra(Intent.EXTRA_TITLE));}
   finally{inst.removeMonitor(monitor);}
  }finally{inst.runOnMainSync(activity::finish);}
 }
}
