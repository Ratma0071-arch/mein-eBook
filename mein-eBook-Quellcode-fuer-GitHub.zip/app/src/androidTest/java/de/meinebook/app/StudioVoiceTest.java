package de.meinebook.app;
import android.content.Context;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Real downloaded weights, JNI frontend and neural waveform on Android. */
@RunWith(AndroidJUnit4.class)
public class StudioVoiceTest {
 @Test public void generatesAllGermanStudioVoicesAndSwitchesEngines()throws Exception{
  Context c=InstrumentationRegistry.getInstrumentation().getTargetContext();
  NeuralSpeech s=new NeuralSpeech(c);
  try{
   s.download("kitten2-mini-de:lena",msg->{});
   for(String voice:new String[]{"lena","greta","jonas","felix","eleanor","martha","serena","iris","grace","edith","diana","otis","vincent"}){
    long start=System.nanoTime();NeuralSpeech.Audio a=s.generate("neural:kitten2-mini-de:"+voice,"Guten Abend! Schön, dass du wieder da bist. Heute lesen wir gemeinsam.",1,1);
    assertEquals(24000,a.getSampleRate());assertTrue(voice,a.getSamples().length>24000);
    float peak=0;for(float x:a.getSamples()){assertTrue(Float.isFinite(x));peak=Math.max(peak,Math.abs(x));}assertTrue(voice,peak>.01f);
    System.out.println("Studio "+voice+": "+a.getSamples().length+" samples in "+(System.nanoTime()-start)/1e9+" seconds");
   }
   s.download("de_DE-thorsten-medium-int8:0",msg->{});
   assertTrue(s.generate("neural:de_DE-thorsten-medium-int8:0","Eine andere Stimme liest weiter.",1,1).getSamples().length>1000);
   assertTrue(s.generate("neural:kitten2-mini-de:lena","Und jetzt wieder die neue Stimme.",1,1).getSamples().length>1000);
  }finally{s.close();}
 }
}
