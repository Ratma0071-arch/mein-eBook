package de.meinebook.app;
import android.app.Instrumentation;
import android.content.*;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.json.*;
import java.io.*;
import static org.junit.Assert.*;

/** Exercises real neural audio, native queue transitions and screen-off playback. */
@RunWith(AndroidJUnit4.class)
public class ScreenOffReadingTest {
  private String waitFor(String state,long seconds) throws Exception {
    long until=System.currentTimeMillis()+seconds*1000;
    while(System.currentTimeMillis()<until){JSONObject s=new JSONObject(ReadAloudService.lastState);if(state.equals(s.optString("state")))return s.toString();if("error".equals(s.optString("state")))fail(s.toString());Thread.sleep(200);}
    fail("Timed out waiting for "+state+": "+ReadAloudService.lastState);return "";
  }
  @Test public void keepsReadingWithScreenOff() throws Exception {
    Instrumentation inst=InstrumentationRegistry.getInstrumentation();Context c=inst.getTargetContext();
    inst.getUiAutomation().executeShellCommand("input keyevent KEYCODE_WAKEUP").close();
    inst.startActivitySync(new Intent(c,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
    NeuralSpeech models=new NeuralSpeech(c);models.download("kitten2-mini-de:lena",msg->{});
    JSONArray parts=new JSONArray();
    for(int i=0;i<3;i++)parts.put(new JSONObject().put("text","Dies ist ein Test der Vorlesefunktion bei gesperrtem Bildschirm. Die nächste Textstelle muss auch ohne sichtbare Oberfläche gelesen werden.").put("voice","neural:kitten2-mini-de:lena").put("lang","de-DE").put("rate",1).put("pitch",1).put("volume",1).put("chapter",0).put("position",i));
    File file=File.createTempFile("reading-test-",".json",c.getFilesDir());try(FileOutputStream out=new FileOutputStream(file)){out.write(new JSONObject().put("parts",parts).put("title","Screen-off test").toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));}
    inst.runOnMainSync(()->c.startForegroundService(new Intent(c,ReadAloudService.class).setAction(ReadAloudService.START).putExtra("path",file.getAbsolutePath())));
    try{
      waitFor("playing",30);ReadAloudService.command("pause");waitFor("paused",10);ReadAloudService.command("resume");waitFor("playing",10);
      inst.getUiAutomation().executeShellCommand("input keyevent KEYCODE_SLEEP").close();
      waitFor("completed",180);
      assertEquals(3,new JSONObject(ReadAloudService.lastState).getInt("index"));
    }finally{ReadAloudService.command("stop");inst.getUiAutomation().executeShellCommand("input keyevent KEYCODE_WAKEUP").close();}
  }
}
