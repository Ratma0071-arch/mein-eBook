package de.meinebook.app;
final class Mp3Encoder implements AutoCloseable {
  static { System.loadLibrary("ebookmp3"); }
  private long handle;
  Mp3Encoder(int sampleRate){handle=open(sampleRate);if(handle==0)throw new IllegalStateException("MP3-Encoder konnte nicht starten");}
  byte[] encode(short[] samples){return encode(handle,samples);}
  byte[] finish(){return finish(handle);}
  public void close(){if(handle!=0){destroy(handle);handle=0;}}
  private static native long open(int sampleRate);
  private static native byte[] encode(long handle,short[] samples);
  private static native byte[] finish(long handle);
  private static native void destroy(long handle);
}
