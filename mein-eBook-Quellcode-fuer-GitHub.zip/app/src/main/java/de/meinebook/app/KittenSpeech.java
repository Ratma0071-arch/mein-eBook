package de.meinebook.app;

import org.json.JSONObject;
import java.io.*;
import java.nio.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;

/** KittenTTS 2 Mini, German frontend. No cloud, telemetry, or downloaded code. */
final class KittenSpeech implements AutoCloseable {
 static {System.loadLibrary("sherpa-onnx-jni");System.loadLibrary("ebookvoice");}
 private static native long open(String model) throws IOException;
 private static native void release(long model);
 private static native float[] infer(long model,long[] tokens,float[] style,float speed) throws IOException;
 private static native String phonemize(String data,String text) throws IOException;
 static native void resetPhonemizer();
 private long model;
 private final File dir;
 private final JSONObject vocab;
 private final Map<String,float[]> styles=new HashMap<>();
 KittenSpeech(File folder)throws Exception {
  dir=folder;
  try(InputStream in=new FileInputStream(new File(dir,"vocab.json"))){vocab=new JSONObject(new String(NeuralSpeech.readBytes(in),StandardCharsets.UTF_8));}
  model=open(new File(dir,"kitten_tts_2_mini.onnx").getAbsolutePath());
 }
 private String phones(String text)throws Exception {
  StringBuilder out=new StringBuilder();
  Matcher m=Pattern.compile("[^,;:.!?…()]+|[,;:.!?…()]").matcher(text);
  while(m.find()){
   String part=m.group();
   if(part.matches("[,;:.!?…()]"))out.append(part);
   else if(!part.trim().isEmpty()){if(out.length()>0)out.append(' ');out.append(phonemize(dir.getAbsolutePath(),part.trim()));}
  }
  String p=out.toString();
  String[][] folds={{"a^ɪ","I"},{"a^ʊ","W"},{"d^z","ʣ"},{"d^ʒ","ʤ"},{"e^ɪ","A"},{"o^ʊ","O"},{"ə^ʊ","Q"},{"s^s","S"},{"t^s","ʦ"},{"t^ʃ","ʧ"},{"ɔ^ɪ","Y"},{"^",""},{"-",""},{"\u032a",""},{"\u0329",""},{"\u030d",""},{"\u032f",""},{"ɭ","l"},{"ɫ","l"},{"ɵ","ø"},{"ε","ɛ"},{"\u202f"," "},{"\u2009"," "},{"\t"," "},{"«",""},{"»",""},{"‘",""},{"’",""},{"'",""},{"~",""},{"·",""},{"#",""},{"g","ɡ"}};
  for(String[] f:folds)p=p.replace(f[0],f[1]);
  return p;
 }
 NeuralSpeech.Audio generate(String text,String voice,float speed)throws Exception {
  if(model==0)throw new IOException("Studio-Sprachmodell ist geschlossen.");
  String p=phones(text);ArrayList<Long> ids=new ArrayList<>();ids.add(0L);
  p.codePoints().forEach(c->{String ch=new String(Character.toChars(c));if(vocab.has(ch))ids.add(vocab.optLong(ch));});
  ids.add(10L);ids.add(0L);
  if(ids.size()>510)throw new IOException("Dieser Satz ist für die Studio-Stimme zu lang. Bitte kürzere Textabschnitte verwenden.");
  if(ids.size()<4)throw new IOException("Dieser Abschnitt enthält keinen vorlesbaren Text.");
  long[] tokens=new long[ids.size()];for(int i=0;i<tokens.length;i++)tokens[i]=ids.get(i);
  if(!voice.matches("[a-z]+"))throw new IOException("Ungültige Studio-Stimme.");
  float[] pack=styles.get(voice);
  if(pack==null){
   File file=new File(dir,"styles/"+voice+".bin");if(file.length()!=510*256*4)throw new IOException("Stimmprofil ist unvollständig.");
   try(InputStream in=new FileInputStream(file)){ByteBuffer bytes=ByteBuffer.wrap(NeuralSpeech.readBytes(in)).order(ByteOrder.LITTLE_ENDIAN);pack=new float[510*256];bytes.asFloatBuffer().get(pack);}styles.put(voice,pack);
  }
  float[] style=Arrays.copyOfRange(pack,(tokens.length-1)*256,tokens.length*256);
  return new NeuralSpeech.Audio(infer(model,tokens,style,Math.max(.35f,Math.min(2.5f,speed))),24000);
 }
 public void close(){if(model!=0){release(model);model=0;}styles.clear();}
}
