package de.meinebook.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.ValueCallback;
import android.util.Base64;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Locale;
import java.util.Set;
import java.io.OutputStream;

public class MainActivity extends Activity {
  private static final int OPEN=101, SAVE=102;
  private WebView web; private TextToSpeech tts; private boolean ttsReady=false;
  private ValueCallback<Uri[]> chooser;
  private Uri originalUri; private byte[] pendingBytes; private String pendingName;
  private int activeSpeech=0;
  private final Handler ui=new Handler(Looper.getMainLooper());

  @Override public void onCreate(Bundle saved){super.onCreate(saved);
    web=new WebView(this);setContentView(web);
    WebSettings ws=web.getSettings();ws.setJavaScriptEnabled(true);ws.setDomStorageEnabled(true);ws.setAllowFileAccess(true);ws.setAllowContentAccess(true);
    web.setWebViewClient(new WebViewClient());
    web.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params){
        if(chooser!=null)chooser.onReceiveValue(null);chooser=callback;
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try{startActivityForResult(i,OPEN);}catch(Exception e){chooser.onReceiveValue(null);chooser=null;toast("Dateiauswahl nicht verfügbar");}
        return true;
      }
    });
    web.addJavascriptInterface(new Bridge(),"AndroidBridge");
    tts=new TextToSpeech(this,status->{ttsReady=status==TextToSpeech.SUCCESS;if(ttsReady){tts.setLanguage(Locale.GERMAN);
      tts.setOnUtteranceProgressListener(new UtteranceProgressListener(){
        @Override public void onStart(String id){}
        @Override public void onDone(String id){js("window.NativeSpeech&&NativeSpeech.done("+id+")");}
        @Override public void onError(String id){js("window.NativeSpeech&&NativeSpeech.error("+id+",'TTS-Fehler')");}
      }); js("window.NativeSpeech&&NativeSpeech.ready()");
    }});
    web.loadUrl("file:///android_asset/index.html");
  }
  private void js(String code){ui.post(()->web.evaluateJavascript(code,null));}
  private void toast(String message){ui.post(()->Toast.makeText(this,message,Toast.LENGTH_LONG).show());}
  private void report(boolean ok,String message){js("window.NativeFile&&NativeFile.result("+ok+","+JSONObject.quote(message)+")");}

  public class Bridge {
    @JavascriptInterface public String voices(){
      JSONArray a=new JSONArray();if(!ttsReady)return a.toString();
      Set<Voice> vv=tts.getVoices();if(vv!=null)for(Voice v:vv){if(v.getLocale()!=null&&v.getLocale().getLanguage().equals("de") && !v.isNetworkConnectionRequired()){
        JSONObject j=new JSONObject();try{j.put("name",v.getName());j.put("lang",v.getLocale().toLanguageTag());a.put(j);}catch(Exception ignored){}
      }}return a.toString();
    }
    @JavascriptInterface public void speak(String text,double rate,double pitch,double volume,String voiceName,int id){
      ui.post(()->{if(!ttsReady){report(false,"Bitte eine deutsche Offline-TTS-Stimme installieren.");return;}
        activeSpeech=id;tts.stop();
        if(voiceName!=null&&!voiceName.isEmpty()){for(Voice v:tts.getVoices()){if(v.getName().equals(voiceName)&&!v.isNetworkConnectionRequired()){tts.setVoice(v);break;}}}
        else tts.setLanguage(Locale.GERMAN);
        tts.setSpeechRate((float)Math.max(.4,Math.min(2,rate)));tts.setPitch((float)Math.max(.5,Math.min(2,pitch)));
        Bundle p=new Bundle();p.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME,(float)Math.max(0,Math.min(1,volume)));
        tts.speak(text,TextToSpeech.QUEUE_FLUSH,p,String.valueOf(id));
      });
    }
    @JavascriptInterface public void stop(){ui.post(()->{if(tts!=null)tts.stop();});}
    @JavascriptInterface public void saveBook(String base64,String name,boolean overwrite){
      try{byte[] data=Base64.decode(base64,Base64.DEFAULT);if(data.length>100*1024*1024){report(false,"Datei zu groß zum Speichern.");return;}
        pendingBytes=data;pendingName=name;
        ui.post(()->{
          if(overwrite && originalUri!=null){writeTo(originalUri,true);return;}
          Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);
          i.setType(name.toLowerCase().endsWith(".epub")?"application/epub+zip":name.toLowerCase().endsWith(".txt")?"text/plain":"text/html");
          i.putExtra(Intent.EXTRA_TITLE,overwrite?name:name.replaceFirst("(\\.[^.]+)$","_korrigiert$1"));
          try{startActivityForResult(i,SAVE);}catch(Exception e){report(false,"Speicherdialog nicht verfügbar.");}
        });
      }catch(Exception e){report(false,"Speichern nicht möglich: "+e.getMessage());}
    }
  }
  private void writeTo(Uri uri,boolean overwrite){
    try{if(pendingBytes==null)throw new Exception("Keine Daten vorhanden");
      try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new Exception("Schreibzugriff verweigert");out.write(pendingBytes);out.flush();}
      pendingBytes=null;report(true,overwrite?"Originaldatei erfolgreich überschrieben.":"Korrigiertes eBook gespeichert.");
    }catch(Exception e){report(false,"Konnte Datei nicht speichern: "+e.getMessage()+". Verwende 'Korrigierte Datei speichern'.");}
  }
  @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
    if(request==OPEN){Uri uri=(result==RESULT_OK&&data!=null)?data.getData():null;
      if(uri!=null){
        try{int flags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);getContentResolver().takePersistableUriPermission(uri,flags);}catch(Exception ignored){}
        // Store source URI only for eBook, not imported voice profiles
        String path=uri.toString().toLowerCase();String name="";
        try(android.database.Cursor c=getContentResolver().query(uri,null,null,null,null)){if(c!=null&&c.moveToFirst()){int ix=c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);if(ix>=0)name=c.getString(ix).toLowerCase();}}catch(Exception ignored){}
        if(name.endsWith(".epub")||name.endsWith(".txt")||name.endsWith(".html")||name.endsWith(".htm"))originalUri=uri;
      }
      if(chooser!=null){chooser.onReceiveValue(uri==null?null:new Uri[]{uri});chooser=null;}
    }else if(request==SAVE){if(result==RESULT_OK&&data!=null&&data.getData()!=null)writeTo(data.getData(),false);else report(false,"Speichern abgebrochen.");}
  }
  @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
  @Override protected void onDestroy(){if(tts!=null){tts.stop();tts.shutdown();}web.destroy();super.onDestroy();}
}
