package de.meinebook.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.ValueCallback;
import android.util.Base64;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Locale;
import java.util.Set;
import java.io.OutputStream;
import java.io.File;
import java.io.RandomAccessFile;

public class MainActivity extends Activity {
  private static final int OPEN=101, SAVE=102;
  private WebView web; private TextToSpeech tts; private boolean ttsReady=false;
  private ValueCallback<Uri[]> chooser;
  private Uri originalUri; private byte[] pendingBytes; private String pendingName;
  private int activeSpeech=0;
  private NeuralSpeech neural;
  private final java.util.concurrent.ExecutorService speechWorker=java.util.concurrent.Executors.newSingleThreadExecutor();
  private volatile int speechToken=0;
  private volatile android.media.AudioTrack audioTrack;
  private volatile boolean exporting=false,cancelExport=false;
  private JSONArray exportPlan;
  private final java.util.concurrent.ConcurrentHashMap<String,java.util.concurrent.CompletableFuture<Boolean>> exportWait=new java.util.concurrent.ConcurrentHashMap<>();
  private static final int EXPORT=103;
  private final Handler ui=new Handler(Looper.getMainLooper());

  @Override public void onCreate(Bundle saved){super.onCreate(saved);
    web=new WebView(this);setContentView(web);
    try{neural=new NeuralSpeech(this);}catch(Exception e){toast("KI-Stimmen konnten nicht geladen werden: "+e.getMessage());}
    WebSettings ws=web.getSettings();ws.setJavaScriptEnabled(true);ws.setDomStorageEnabled(true);ws.setAllowFileAccess(true);ws.setAllowContentAccess(true);
    ws.setBlockNetworkLoads(true);
    web.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView v,android.webkit.WebResourceRequest r){return !r.getUrl().toString().startsWith("file:///android_asset/");}
    });
    web.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params){
        if(chooser!=null)chooser.onReceiveValue(null);chooser=callback;
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try{startActivityForResult(i,OPEN);}catch(Exception e){chooser.onReceiveValue(null);chooser=null;toast("Dateiauswahl nicht verfügbar");}
        return true;
      }
    });
    web.addJavascriptInterface(new Bridge(),"AndroidBridge");
    tts=new TextToSpeech(this,status->{ttsReady=status==TextToSpeech.SUCCESS;if(ttsReady){tts.setLanguage(Locale.GERMAN);
      tts.setOnUtteranceProgressListener(new UtteranceProgressListener(){
        @Override public void onStart(String id){}
        @Override public void onDone(String id){if(finishExportSpeech(id,true)||!id.matches("[0-9]+"))return;js("window.NativeSpeech&&NativeSpeech.done("+id+")");}
        @Override public void onError(String id){if(finishExportSpeech(id,false)||!id.matches("[0-9]+"))return;js("window.NativeSpeech&&NativeSpeech.error("+id+",'TTS-Fehler')");}
      }); js("window.NativeSpeech&&NativeSpeech.ready()");
    }});
    web.loadUrl("file:///android_asset/index.html");
  }
  private void js(String code){ui.post(()->web.evaluateJavascript(code,null));}
  private void toast(String message){ui.post(()->Toast.makeText(this,message,Toast.LENGTH_LONG).show());}
  private void report(boolean ok,String message){js("window.NativeFile&&NativeFile.result("+ok+","+JSONObject.quote(message)+")");}

  public class Bridge {
    @JavascriptInterface public String voices(){
      JSONArray a=new JSONArray();
      try{if(neural!=null){JSONArray nv=neural.voices();for(int i=0;i<nv.length();i++)a.put(nv.get(i));}}catch(Exception ignored){}
      if(!ttsReady)return a.toString();
      Set<Voice> vv=tts.getVoices();if(vv!=null)for(Voice v:vv){if(v.getLocale()!=null&&java.util.Arrays.asList("de","en","fr","it","es").contains(v.getLocale().getLanguage()) && !v.isNetworkConnectionRequired()){
        JSONObject j=new JSONObject();try{j.put("name",v.getName());j.put("lang",v.getLocale().toLanguageTag());j.put("uri",v.getName());j.put("installed",true);j.put("gender","unknown");a.put(j);}catch(Exception ignored){}
      }}return a.toString();
    }
    @JavascriptInterface public void speak(String text,double rate,double pitch,double volume,String voiceName,String language,int id){
      if(exporting){speechError(id,"Hörbuch-Export läuft. Bitte zuerst beenden.");return;}
      if(text==null||text.length()>2000){speechError(id,"Textabschnitt zu lang.");return;}
      int token=++speechToken;
      ui.post(()->{if(tts!=null)tts.stop();stopTrack();});
      if(voiceName!=null&&voiceName.startsWith("neural:")){
        speechWorker.execute(()->{
          try{
            if(token!=speechToken)return;
            if(neural==null)throw new Exception("KI-Sprachausgabe nicht verfügbar");
            com.k2fsa.sherpa.onnx.GeneratedAudio a=neural.generate(voiceName,text,(float)rate,(float)pitch);
            short[] pcm=convert(a.getSamples(),a.getSampleRate(),22050,(float)pitch,(float)volume);
            if(token!=speechToken)return;
            android.media.AudioTrack track=new android.media.AudioTrack.Builder()
              .setAudioAttributes(new android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_MEDIA).setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH).build())
              .setAudioFormat(new android.media.AudioFormat.Builder().setSampleRate(22050).setEncoding(android.media.AudioFormat.ENCODING_PCM_16BIT).setChannelMask(android.media.AudioFormat.CHANNEL_OUT_MONO).build())
              .setBufferSizeInBytes(Math.max(4096,android.media.AudioTrack.getMinBufferSize(22050,android.media.AudioFormat.CHANNEL_OUT_MONO,android.media.AudioFormat.ENCODING_PCM_16BIT)))
              .setTransferMode(android.media.AudioTrack.MODE_STREAM).build();
            audioTrack=track;
            try{
              track.play();int offset=0;
              while(offset<pcm.length&&token==speechToken){int n=track.write(pcm,offset,Math.min(2048,pcm.length-offset),android.media.AudioTrack.WRITE_BLOCKING);if(n<0)throw new Exception("Audioausgabe fehlgeschlagen");offset+=n;}
              while(token==speechToken&&Integer.toUnsignedLong(track.getPlaybackHeadPosition())<pcm.length)Thread.sleep(20);
            }finally{if(audioTrack==track)audioTrack=null;track.release();}
            if(token==speechToken)js("window.NativeSpeech&&NativeSpeech.done("+id+")");
          }catch(Throwable e){if(token==speechToken)speechError(id,"KI-Stimme: "+e.getMessage());}
        });
      }else ui.post(()->{
        try{if(token!=speechToken)return;if(!ttsReady)throw new Exception("Gerätestimme noch nicht bereit");
          setSystemVoice(voiceName,language,(float)rate,(float)pitch);
          Bundle p=new Bundle();p.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME,(float)volume);
          if(tts.speak(text,TextToSpeech.QUEUE_FLUSH,p,String.valueOf(id))==TextToSpeech.ERROR)throw new Exception("Sprachausgabe fehlgeschlagen");
        }catch(Exception e){speechError(id,e.getMessage());}
      });
    }
    @JavascriptInterface public void stop(){if(exporting)return;++speechToken;ui.post(()->{if(tts!=null)tts.stop();stopTrack();});}
    @JavascriptInterface public void downloadVoice(String id){
      new Thread(()->{try{if(neural==null)throw new Exception("KI-Engine fehlt");neural.download(id,msg->js("window.VoiceStudio&&VoiceStudio.downloadStatus("+JSONObject.quote(msg)+",false)"));js("window.VoiceStudio&&VoiceStudio.downloadStatus('KI-Stimme installiert.',true)");}
        catch(Exception e){js("window.VoiceStudio&&VoiceStudio.downloadStatus("+JSONObject.quote("Download fehlgeschlagen: "+e.getMessage())+",true)");}},"voice-download").start();
    }
    @JavascriptInterface public void cancelAudioExport(){cancelExport=true;}
    @JavascriptInterface public void exportAudio(String plan,String name){
      if(exporting)return;
      try{JSONArray p=new JSONArray(plan);if(p.length()==0||p.length()>200000)throw new Exception("Ungültiger Hörbuchtext");
        exportPlan=p;
        ui.post(()->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("audio/mpeg");i.putExtra(Intent.EXTRA_TITLE,name.replaceAll("[^\\p{L}\\p{N} ._-]","_")+".mp3");try{startActivityForResult(i,EXPORT);}catch(Exception e){exportStatus("Speicherdialog nicht verfügbar",true);}});
      }catch(Exception e){exportStatus("Export nicht möglich: "+e.getMessage(),true);}
    }
    @JavascriptInterface public void pinShortcut(){ui.post(()->{
      android.content.pm.ShortcutManager sm=getSystemService(android.content.pm.ShortcutManager.class);
      if(sm!=null&&sm.isRequestPinShortcutSupported()){
        android.content.pm.ShortcutInfo shortcut=new android.content.pm.ShortcutInfo.Builder(MainActivity.this,"mein-ebook-reader")
          .setShortLabel("mein eBook").setLongLabel("mein eBook – KI-Vorleser")
          .setIcon(android.graphics.drawable.Icon.createWithResource(MainActivity.this,R.drawable.ic_ebook))
          .setIntent(new Intent(MainActivity.this,MainActivity.class).setAction(Intent.ACTION_MAIN)).build();
        sm.requestPinShortcut(shortcut,null);toast("Bitte das Hinzufügen zum Startbildschirm bestätigen.");
      }else toast("App-Symbol in der App-Übersicht gedrückt halten und auf den Startbildschirm ziehen.");
    });}
    @JavascriptInterface public void saveBook(String base64,String name,boolean overwrite){
      try{byte[] data=Base64.decode(base64,Base64.DEFAULT);if(data.length>100*1024*1024){report(false,"Datei zu groß zum Speichern.");return;}
        pendingBytes=data;pendingName=name;
        ui.post(()->{
          if(overwrite && originalUri!=null){writeTo(originalUri,true);return;}
          Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);
          i.setType(name.toLowerCase().endsWith(".epub")?"application/epub+zip":name.toLowerCase().endsWith(".txt")?"text/plain":"text/html");
          i.putExtra(Intent.EXTRA_TITLE,overwrite?name:name.replaceFirst("(\\.[^.]+)$","_korrigiert$1"));
          try{startActivityForResult(i,SAVE);}catch(Exception e){report(false,"Speicherdialog nicht verfügbar.");}
        });
      }catch(Exception e){report(false,"Speichern nicht möglich: "+e.getMessage());}
    }
  }
  private void writeTo(Uri uri,boolean overwrite){
    try{if(pendingBytes==null)throw new Exception("Keine Daten vorhanden");
      try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new Exception("Schreibzugriff verweigert");out.write(pendingBytes);out.flush();}
      pendingBytes=null;report(true,overwrite?"Originaldatei erfolgreich überschrieben.":"Korrigiertes eBook gespeichert.");
    }catch(Exception e){report(false,"Konnte Datei nicht speichern: "+e.getMessage()+". Verwende 'Korrigierte Datei speichern'.");}
  }
  @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
    if(request==OPEN){Uri uri=(result==RESULT_OK&&data!=null)?data.getData():null;
      if(uri!=null){
        try{int flags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);getContentResolver().takePersistableUriPermission(uri,flags);}catch(Exception ignored){}
        // Store source URI only for eBook, not imported voice profiles
        String path=uri.toString().toLowerCase();String name="";
        try(android.database.Cursor c=getContentResolver().query(uri,null,null,null,null)){if(c!=null&&c.moveToFirst()){int ix=c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);if(ix>=0)name=c.getString(ix).toLowerCase();}}catch(Exception ignored){}
        if(name.endsWith(".epub")||name.endsWith(".txt")||name.endsWith(".html")||name.endsWith(".htm"))originalUri=uri;
      }
      if(chooser!=null){chooser.onReceiveValue(uri==null?null:new Uri[]{uri});chooser=null;}
    }else if(request==EXPORT){
      if(result==RESULT_OK&&data!=null&&data.getData()!=null){JSONArray plan=exportPlan;exportPlan=null;startAudioExport(plan,data.getData());}
      else{exportPlan=null;exportStatus("MP3-Export abgebrochen.",true);}
    }else if(request==SAVE){if(result==RESULT_OK&&data!=null&&data.getData()!=null)writeTo(data.getData(),false);else report(false,"Speichern abgebrochen.");}
  }

  private boolean finishExportSpeech(String id,boolean ok){java.util.concurrent.CompletableFuture<Boolean> f=exportWait.remove(id);if(f==null)return false;f.complete(ok);return true;}
  private void stopTrack(){android.media.AudioTrack t=audioTrack;if(t!=null)try{t.pause();t.flush();}catch(Exception ignored){}}
  private void speechError(int id,String msg){js("window.NativeSpeech&&NativeSpeech.error("+id+","+JSONObject.quote(msg)+")");}
  private void exportStatus(String msg,boolean done){js("window.VoiceStudio&&VoiceStudio.exportStatus("+JSONObject.quote(msg)+","+done+")");}
  private void setSystemVoice(String name,String lang,float rate,float pitch) throws Exception {
    Voice selected=null;Set<Voice> vs=tts.getVoices();if(vs!=null)for(Voice v:vs)if(v.getName().equals(name)&&!v.isNetworkConnectionRequired())selected=v;
    if(selected==null)throw new Exception("Bitte eine installierte Offline-Stimme auswählen.");
    if(!selected.getLocale().getLanguage().equals(Locale.forLanguageTag(lang).getLanguage()))throw new Exception("Die Stimme passt nicht zur gewählten Sprache.");
    if(tts.setVoice(selected)==TextToSpeech.ERROR)throw new Exception("Stimme nicht verfügbar");
    tts.setSpeechRate(Math.max(.4f,Math.min(2,rate)));tts.setPitch(Math.max(.5f,Math.min(2,pitch)));
  }
  static short[] convert(float[] samples,int sourceRate,int targetRate,float pitch,float volume){
    double step=(double)sourceRate/targetRate*Math.max(.65,Math.min(1.55,pitch));int size=(int)(samples.length/step);short[] out=new short[size];
    for(int i=0;i<size;i++){double p=i*step;int j=(int)p;float v=samples[j];if(j+1<samples.length)v+=(samples[j+1]-v)*(p-j);out[i]=(short)(Math.max(-1,Math.min(1,v*volume))*32767);}
    return out;
  }
  private short[] systemAudio(JSONObject part,int index) throws Exception {
    if(!ttsReady)throw new Exception("Gerätestimme noch nicht bereit");
    File tmp=new File(getCacheDir(),"speech-export-"+index+".wav");String id="export-"+index;
    java.util.concurrent.CompletableFuture<Boolean> wait=new java.util.concurrent.CompletableFuture<>();exportWait.put(id,wait);
    ui.post(()->{try{setSystemVoice(part.getString("voice"),part.getString("lang"),(float)part.optDouble("rate",1),(float)part.optDouble("pitch",1));
      if(tts.synthesizeToFile(part.getString("text"),new Bundle(),tmp,id)==TextToSpeech.ERROR)finishExportSpeech(id,false);
    }catch(Exception e){finishExportSpeech(id,false);}});
    try{
      boolean ok=false;for(int t=0;t<120;t++){if(cancelExport)throw new Exception("Abgebrochen");try{ok=wait.get(1,java.util.concurrent.TimeUnit.SECONDS);break;}catch(java.util.concurrent.TimeoutException ignored){}}
      if(!ok)throw new Exception("Gerätestimme konnte keine Audiodatei erzeugen");
      try(RandomAccessFile f=new RandomAccessFile(tmp,"r")){
        byte[] head=new byte[12];f.readFully(head);if(!new String(head,0,4,java.nio.charset.StandardCharsets.US_ASCII).equals("RIFF"))throw new Exception("Unbekanntes Audioformat der Gerätestimme");
        int channels=1,rate=22050,bits=16,format=1;long dataPos=-1;int dataSize=0;
        while(f.getFilePointer()+8<=f.length()){
          byte[] tag=new byte[4];f.readFully(tag);int len=Integer.reverseBytes(f.readInt());long begin=f.getFilePointer();if(len<0||begin+len>f.length())break;
          String type=new String(tag,java.nio.charset.StandardCharsets.US_ASCII);
          if(type.equals("fmt ")&&len>=16){format=Short.reverseBytes(f.readShort());channels=Short.reverseBytes(f.readShort());rate=Integer.reverseBytes(f.readInt());f.skipBytes(6);bits=Short.reverseBytes(f.readShort());}
          if(type.equals("data")){dataPos=begin;dataSize=len;break;}f.seek(begin+len+(len&1));
        }
        if(dataPos<0||format!=1||bits!=16||channels<1||channels>2||dataSize>50*1024*1024)throw new Exception("Gerätestimme muss PCM-WAV mit 16 Bit erzeugen");
        f.seek(dataPos);float[] pcm=new float[dataSize/2/channels];for(int i=0;i<pcm.length;i++){float sum=0;for(int c=0;c<channels;c++)sum+=Short.reverseBytes(f.readShort())/32768f;pcm[i]=sum/channels;}
        return convert(pcm,rate,22050,1,(float)part.optDouble("volume",1));
      }
    }finally{exportWait.remove(id);tmp.delete();}
  }
  private void startAudioExport(JSONArray plan,Uri uri){
    if(plan==null||exporting){exportStatus("Kein Exportauftrag vorhanden.",true);return;}
    exporting=true;cancelExport=false;++speechToken;if(tts!=null)tts.stop();stopTrack();
    getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    speechWorker.execute(()->{
      File mp3=new File(getCacheDir(),"ebook-export.mp3");
      try{
        try(OutputStream file=new java.io.BufferedOutputStream(new java.io.FileOutputStream(mp3));Mp3Encoder encoder=new Mp3Encoder(22050)){
          for(int i=0;i<plan.length();i++){
            if(cancelExport)throw new Exception("MP3-Export abgebrochen");JSONObject part=plan.getJSONObject(i);String text=part.getString("text"),voice=part.getString("voice");
            if(text.length()>2000)throw new Exception("Textabschnitt zu lang");
            exportStatus("MP3 wird erstellt: "+(i+1)+" / "+plan.length()+" · App bitte geöffnet lassen.",false);
            short[] pcm;
            if(voice.startsWith("neural:")){
              com.k2fsa.sherpa.onnx.GeneratedAudio a=neural.generate(voice,text,(float)part.optDouble("rate",1),(float)part.optDouble("pitch",1));
              pcm=convert(a.getSamples(),a.getSampleRate(),22050,(float)part.optDouble("pitch",1),(float)part.optDouble("volume",1));
            }else pcm=systemAudio(part,i);
            file.write(encoder.encode(pcm));int pause=(int)(Math.max(0,Math.min(2,part.optDouble("pause",0)))*22050);if(pause>0)file.write(encoder.encode(new short[pause]));
            if(mp3.length()>2L*1024*1024*1024)throw new Exception("MP3 zu groß. Bitte einzelne Kapitel exportieren.");
          }
          file.write(encoder.finish());
        }
        if(cancelExport)throw new Exception("MP3-Export abgebrochen");
        try(java.io.InputStream in=new java.io.FileInputStream(mp3);OutputStream out=getContentResolver().openOutputStream(uri,"wt")){
          if(out==null)throw new Exception("Kein Schreibzugriff");byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)out.write(b,0,n);
        }
        exportStatus("MP3-Hörbuch gespeichert.",true);
      }catch(Throwable e){try{DocumentsContract.deleteDocument(getContentResolver(),uri);}catch(Exception ignored){}exportStatus("Export: "+e.getMessage(),true);}
      finally{mp3.delete();exporting=false;ui.post(()->getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON));}
    });
  }
  @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
  @Override protected void onDestroy(){cancelExport=true;++speechToken;stopTrack();speechWorker.shutdownNow();if(tts!=null){tts.stop();tts.shutdown();}web.destroy();super.onDestroy();}
}
