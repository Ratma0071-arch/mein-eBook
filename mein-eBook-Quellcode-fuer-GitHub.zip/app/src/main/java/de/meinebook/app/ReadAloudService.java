package de.meinebook.app;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.media.*;
import android.media.session.*;
import android.os.*;
import android.speech.tts.*;
import org.json.*;
import java.io.*;
import java.lang.ref.WeakReference;
import java.util.*;
import java.util.concurrent.*;

/** Owns the entire reading queue; no WebView callbacks or timers are needed. */
public class ReadAloudService extends Service {
  static final String START="start",PAUSE="pause",RESUME="resume",STOP="stop",NEXT="next",PREVIOUS="previous";
  static volatile ReadAloudService running;
  static volatile String lastState="{\"state\":\"idle\"}";
  interface Listener {void changed(String state);}
  static WeakReference<Listener> listener=new WeakReference<>(null);
  static void command(String action){ReadAloudService s=running;if(s!=null)s.main.post(()->s.handle(action));}
  private final Handler main=new Handler(Looper.getMainLooper());
  private final ExecutorService worker=Executors.newSingleThreadExecutor();
  private JSONArray queue=new JSONArray();
  private int position=0;
  private volatile int epoch=0;
  private volatile boolean playing=false;
  private boolean ttsReady=false,focusHeld=false;
  private String title="mein eBook";
  private TextToSpeech tts;
  private NeuralSpeech neural;
  private volatile AudioTrack track;
  private PowerManager.WakeLock wake;
  private MediaSession session;
  private AudioManager audio;
  private AudioFocusRequest focusRequest;
  private final BroadcastReceiver noisy=new BroadcastReceiver(){public void onReceive(Context c,Intent i){handle(PAUSE);}};
  public IBinder onBind(Intent i){return null;}
  @Override public void onCreate(){super.onCreate();running=this;
    NotificationChannel channel=new NotificationChannel("reading","Vorlesen",NotificationManager.IMPORTANCE_LOW);
    channel.setSound(null,null);getSystemService(NotificationManager.class).createNotificationChannel(channel);
    wake=((PowerManager)getSystemService(POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"meinEBook:reading");wake.setReferenceCounted(false);
    audio=(AudioManager)getSystemService(AUDIO_SERVICE);
    AudioAttributes attributes=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build();
    focusRequest=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN).setAudioAttributes(attributes).setOnAudioFocusChangeListener(change->{if(change<0)handle(PAUSE);},main).build();
    session=new MediaSession(this,"mein eBook");
    session.setCallback(new MediaSession.Callback(){public void onPlay(){handle(RESUME);}public void onPause(){handle(PAUSE);}public void onStop(){handle(STOP);}public void onSkipToNext(){handle(NEXT);}public void onSkipToPrevious(){handle(PREVIOUS);}});
    session.setActive(true);
    if(Build.VERSION.SDK_INT>=33)registerReceiver(noisy,new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY),Context.RECEIVER_NOT_EXPORTED);else registerReceiver(noisy,new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY));
    tts=new TextToSpeech(this,status->{ttsReady=status==TextToSpeech.SUCCESS;
      if(ttsReady){tts.setOnUtteranceProgressListener(new UtteranceProgressListener(){public void onStart(String id){}public void onDone(String id){main.post(()->complete(id));}public void onError(String id){main.post(()->{if(id.equals(String.valueOf(epoch))&&playing)fail("Gerätestimme konnte nicht lesen.");});}});if(playing&&position<queue.length()&&!queue.optJSONObject(position).optString("voice").startsWith("neural:"))next();}
      else if(playing&&position<queue.length()&&!queue.optJSONObject(position).optString("voice").startsWith("neural:"))fail("Gerätestimme nicht verfügbar.");
    });
  }
  @Override public int onStartCommand(Intent intent,int flags,int startId){
    if(intent==null){stopSelf();return START_NOT_STICKY;}
    String action=intent.getAction();
    if(START.equals(action)){
      // Enter foreground before parsing a potentially large queue or loading any model.
      foreground();epoch++;stopAudio();playing=false;
      try{
        File file=new File(intent.getStringExtra("path"));if(!file.getCanonicalFile().getParentFile().equals(getFilesDir().getCanonicalFile())||file.length()>16L*1024*1024)throw new IOException("Ungültige Lesewarteschlange");
        try(InputStream in=new FileInputStream(file)){JSONObject data=new JSONObject(new String(NeuralSpeech.readBytes(in),java.nio.charset.StandardCharsets.UTF_8));queue=data.getJSONArray("parts");title=data.optString("title","mein eBook");}file.delete();
        if(queue.length()==0)throw new IOException("Kein Vorlesetext");position=0;handle(RESUME);
      }catch(Exception e){fail(e.getMessage());}
    }else handle(action);
    return START_NOT_STICKY;
  }
  private void handle(String action){
    if(STOP.equals(action)){playing=false;epoch++;stopAudio();releaseFocus();publish("idle","");stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();return;}
    if(PAUSE.equals(action)){if(!playing)return;playing=false;epoch++;stopAudio();releaseFocus();publish("paused","");notifyPlayer();return;}
    if(NEXT.equals(action)||PREVIOUS.equals(action)){epoch++;stopAudio();position=Math.max(0,Math.min(queue.length(),position+(NEXT.equals(action)?1:-1)));if(playing)next();else {publish("paused","");notifyPlayer();}return;}
    if(RESUME.equals(action)){
      if(queue.length()==0)return;
      foreground();
      if(audio.requestAudioFocus(focusRequest)!=AudioManager.AUDIOFOCUS_REQUEST_GRANTED){fail("Eine andere App verwendet die Audioausgabe.");return;}
      focusHeld=true;playing=true;wake.acquire(60*60*1000L);next();
    }
  }
  private void foreground(){Notification n=notification();if(Build.VERSION.SDK_INT>=29)startForeground(41,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);else startForeground(41,n);}
  private void next(){
    if(!playing)return;
    if(position>=queue.length()){playing=false;epoch++;stopAudio();releaseFocus();publish("completed","");stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();return;}
    JSONObject part=queue.optJSONObject(position);if(part==null){fail("Ungültiger Textabschnitt");return;}
    if(!part.optString("voice").startsWith("neural:")&&!ttsReady)return;
    final int token=++epoch;wake.acquire(60*60*1000L);publish("playing","");notifyPlayer();
    String voice=part.optString("voice"),text=part.optString("text");if(text.isEmpty()||text.length()>2000){fail("Ungültiger Textabschnitt");return;}
    if(voice.startsWith("neural:"))worker.execute(()->{
      try{
        if(neural==null)neural=new NeuralSpeech(this);
        NeuralSpeech.Audio generated=neural.generate(voice,text,(float)part.optDouble("rate",1),(float)part.optDouble("pitch",1));
        short[] pcm=MainActivity.convert(generated.getSamples(),generated.getSampleRate(),22050,(float)part.optDouble("pitch",1),(float)part.optDouble("volume",1));
        if(token!=epoch||!playing)return;
        AudioTrack player=new AudioTrack.Builder().setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
          .setAudioFormat(new AudioFormat.Builder().setSampleRate(22050).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
          .setBufferSizeInBytes(Math.max(4096,AudioTrack.getMinBufferSize(22050,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT))).setTransferMode(AudioTrack.MODE_STREAM).build();track=player;
        try{player.play();int offset=0;while(offset<pcm.length&&token==epoch&&playing){int n=player.write(pcm,offset,Math.min(2048,pcm.length-offset),AudioTrack.WRITE_BLOCKING);if(n<0)throw new IOException("Audioausgabe fehlgeschlagen");offset+=n;}
          while(token==epoch&&playing&&Integer.toUnsignedLong(player.getPlaybackHeadPosition())<pcm.length)Thread.sleep(20);
        }finally{if(track==player)track=null;player.release();}
        main.post(()->complete(String.valueOf(token)));
      }catch(Throwable e){main.post(()->{if(token==epoch)fail("KI-Stimme: "+e.getMessage());});}
    });
    else try{
      Voice selected=null;Set<Voice> available=tts.getVoices();if(available!=null)for(Voice v:available)if(v.getName().equals(voice)&&!v.isNetworkConnectionRequired())selected=v;
      if(selected==null||tts.setVoice(selected)==TextToSpeech.ERROR)throw new IOException("Offline-Gerätestimme fehlt");
      tts.setSpeechRate((float)part.optDouble("rate",1));tts.setPitch((float)part.optDouble("pitch",1));Bundle b=new Bundle();b.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME,(float)part.optDouble("volume",1));
      if(tts.speak(text,TextToSpeech.QUEUE_FLUSH,b,String.valueOf(token))==TextToSpeech.ERROR)throw new IOException("Gerätestimme fehlgeschlagen");
    }catch(Exception e){fail(e.getMessage());}
  }
  private void complete(String id){if(!id.equals(String.valueOf(epoch))||!playing)return;JSONObject part=queue.optJSONObject(position);position++;int token=epoch;long pause=part==null?0:(long)(Math.max(0,Math.min(2,part.optDouble("pause",0)))*1000);main.postDelayed(()->{if(token==epoch&&playing)next();},pause);}
  private void stopAudio(){if(tts!=null)tts.stop();AudioTrack t=track;if(t!=null)try{t.pause();t.flush();}catch(Exception ignored){}}
  private void releaseFocus(){if(wake.isHeld())wake.release();if(focusHeld){focusHeld=false;audio.abandonAudioFocusRequest(focusRequest);}}
  private void fail(String message){playing=false;epoch++;stopAudio();releaseFocus();publish("error",message);stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();}
  private void publish(String state,String error){
    JSONObject p=queue.optJSONObject(Math.min(position,Math.max(0,queue.length()-1))),data=new JSONObject();
    try{data.put("state",state);data.put("title",title);data.put("chapter",p==null?0:p.optInt("chapter"));data.put("position",p==null?0:p.optInt("position"));data.put("index",position);data.put("total",queue.length());data.put("error",error);lastState=data.toString();}catch(Exception ignored){}
    Listener l=listener.get();if(l!=null)l.changed(lastState);
    session.setPlaybackState(new PlaybackState.Builder().setActions(PlaybackState.ACTION_PLAY|PlaybackState.ACTION_PAUSE|PlaybackState.ACTION_STOP|PlaybackState.ACTION_SKIP_TO_NEXT|PlaybackState.ACTION_SKIP_TO_PREVIOUS).setState(playing?PlaybackState.STATE_PLAYING:PlaybackState.STATE_PAUSED,PlaybackState.PLAYBACK_POSITION_UNKNOWN,playing?1:0).build());
    session.setMetadata(new MediaMetadata.Builder().putString(MediaMetadata.METADATA_KEY_TITLE,title).putString(MediaMetadata.METADATA_KEY_ARTIST,"mein eBook").build());
  }
  private PendingIntent action(String action,int id){return PendingIntent.getService(this,id,new Intent(this,ReadAloudService.class).setAction(action),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
  private Notification notification(){
    PendingIntent open=PendingIntent.getActivity(this,1,new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    return new Notification.Builder(this,"reading").setSmallIcon(R.drawable.ic_audio).setContentTitle(title).setContentText((playing?"Vorlesen":"Pausiert")+" · Abschnitt "+Math.min(position+1,queue.length())+" / "+queue.length()).setContentIntent(open)
      .setVisibility(Notification.VISIBILITY_PRIVATE).setOnlyAlertOnce(true).setOngoing(playing)
      .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_previous,"Zurück",action(PREVIOUS,2)).build())
      .addAction(new Notification.Action.Builder(playing?android.R.drawable.ic_media_pause:android.R.drawable.ic_media_play,playing?"Pause":"Weiter",action(playing?PAUSE:RESUME,3)).build())
      .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_next,"Weiter",action(NEXT,4)).build())
      .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,"Beenden",action(STOP,5)).build())
      .setStyle(new Notification.MediaStyle().setMediaSession(session.getSessionToken()).setShowActionsInCompactView(0,1,2)).build();
  }
  private void notifyPlayer(){getSystemService(NotificationManager.class).notify(41,notification());}
  @Override public void onDestroy(){playing=false;epoch++;stopAudio();releaseFocus();if(tts!=null)tts.shutdown();try{unregisterReceiver(noisy);}catch(Exception ignored){}session.release();worker.execute(()->{if(neural!=null)neural.close();});worker.shutdown();if(running==this)running=null;super.onDestroy();}
}
