package de.meinebook.app;

import android.content.Context;
import com.k2fsa.sherpa.onnx.*;
import org.json.*;
import org.apache.commons.compress.archivers.tar.*;
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
import java.io.*;
import java.net.*;
import java.security.MessageDigest;
import java.util.*;

/** Neural inference and verified, explicitly requested voice-pack downloads. */
final class NeuralSpeech {
  private final Context context;
  private final File root;
  private final JSONArray catalog;
  private OfflineTts engine;
  private String loaded = "";
  NeuralSpeech(Context c) throws Exception {
    context=c; root=new File(c.getFilesDir(),"voices"); root.mkdirs();
    try(InputStream in=c.getAssets().open("voices.json")){catalog=new JSONArray(new String(readBytes(in),java.nio.charset.StandardCharsets.UTF_8));}
  }
  static byte[] readBytes(InputStream in) throws IOException {ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return out.toByteArray();}
  JSONObject entry(String id) throws Exception {
    for(int i=0;i<catalog.length();i++){JSONObject v=catalog.getJSONObject(i);if(v.getString("id").equals(id))return v;}
    throw new IOException("Unbekannte KI-Stimme");
  }
  JSONArray voices() throws Exception {
    JSONArray out=new JSONArray();
    for(int i=0;i<catalog.length();i++){
      JSONObject v=new JSONObject(catalog.getJSONObject(i).toString());
      v.put("name","KI · "+v.getString("name"));v.put("uri","neural:"+v.getString("id"));
      v.put("installed",new File(root,v.getString("pack")+"/ready").isFile());out.put(v);
    }return out;
  }
  interface Progress { void update(String text); }
  synchronized void close(){if(engine!=null){engine.release();engine=null;loaded="";}}
  void download(String id,Progress progress) throws Exception {
    JSONObject v=entry(id);String pack=v.getString("pack");
    if(new File(root,pack+"/ready").isFile()){progress.update("Stimme bereits installiert.");return;}
    File archive=new File(root,pack+".part"),stage=new File(root,pack+".stage");remove(stage);stage.mkdirs();
    try {
      MessageDigest digest=MessageDigest.getInstance("SHA-256");
      HttpURLConnection conn=(HttpURLConnection)new URL(v.getString("url")).openConnection();
      conn.setConnectTimeout(30000);conn.setReadTimeout(60000);
      long count=0,last=0,total=v.getLong("bytes");
      try(InputStream in=new BufferedInputStream(conn.getInputStream());OutputStream out=new FileOutputStream(archive)){
        byte[] b=new byte[65536];int n;
        while((n=in.read(b))!=-1){count+=n;if(count>total)throw new IOException("Stimmenpaket zu groß");digest.update(b,0,n);out.write(b,0,n);
          if(count-last>512000){progress.update("Stimme laden: "+(count*100/total)+" %");last=count;}}
      } finally {conn.disconnect();}
      StringBuilder hash=new StringBuilder();for(byte b:digest.digest())hash.append(String.format(Locale.ROOT,"%02x",b&255));
      if(count!=total||!hash.toString().equals(v.getString("sha256")))throw new IOException("Prüfsumme des Stimmenpakets stimmt nicht");
      progress.update("Stimme wird eingerichtet …");long expanded=0;int entries=0;
      try(TarArchiveInputStream tar=new TarArchiveInputStream(new BZip2CompressorInputStream(new BufferedInputStream(new FileInputStream(archive))))){
        TarArchiveEntry e;byte[] b=new byte[65536];
        while((e=tar.getNextTarEntry())!=null){
          if(++entries>5000||e.isSymbolicLink()||e.isLink())throw new IOException("Ungültiges Stimmenpaket");
          String name=e.getName();if(name.equals(pack)||name.equals(pack+"/"))continue;if(!name.startsWith(pack+"/"))throw new IOException("Ungültiger Paketpfad");
          name=name.substring(pack.length()+1);if(name.isEmpty())continue;
          File f=new File(stage,name);if(!f.getCanonicalPath().startsWith(stage.getCanonicalPath()+File.separator))throw new IOException("Ungültiger Dateipfad");
          if(e.isDirectory()){f.mkdirs();continue;}if(!e.isFile())throw new IOException("Ungültiger Dateityp");
          expanded+=e.getSize();if(expanded>300L*1024*1024)throw new IOException("Paket überschreitet Speichergrenze");
          f.getParentFile().mkdirs();try(OutputStream out=new FileOutputStream(f)){int n;while((n=tar.read(b))!=-1)out.write(b,0,n);}
        }
      }
      if(findModel(stage)==null||!new File(stage,"tokens.txt").isFile()||!new File(stage,"espeak-ng-data").isDirectory())throw new IOException("Stimmenpaket unvollständig");
      try(FileOutputStream out=new FileOutputStream(new File(stage,"ready"))){out.write(1);}
      File finalDir=new File(root,pack);remove(finalDir);if(!stage.renameTo(finalDir))throw new IOException("Stimme konnte nicht gespeichert werden");
      progress.update("KI-Stimme installiert. Vorlesen funktioniert jetzt offline.");
    } finally {archive.delete();remove(stage);}
  }
  private File findModel(File dir){File[] fs=dir.listFiles();if(fs!=null)for(File f:fs)if(f.getName().endsWith(".onnx"))return f;return null;}
  synchronized GeneratedAudio generate(String uri,String text,float rate,float pitch) throws Exception {
    JSONObject v=entry(uri.substring(7));File dir=new File(root,v.getString("pack"));
    if(!new File(dir,"ready").isFile())throw new IOException("Bitte diese KI-Stimme zuerst herunterladen.");
    if(!loaded.equals(v.getString("pack"))){
      close();File modelFile=findModel(dir);if(modelFile==null)throw new IOException("Sprachmodell fehlt");
      OfflineTtsVitsModelConfig vits=new OfflineTtsVitsModelConfig();
      vits.setModel(modelFile.getAbsolutePath());vits.setTokens(new File(dir,"tokens.txt").getAbsolutePath());vits.setDataDir(new File(dir,"espeak-ng-data").getAbsolutePath());
      OfflineTtsModelConfig model=new OfflineTtsModelConfig();model.setVits(vits);model.setNumThreads(2);
      OfflineTtsConfig config=new OfflineTtsConfig();config.setModel(model);
      engine=new OfflineTts(null,config);loaded=v.getString("pack");
    }
    int sid=v.getInt("sid");if(sid>=engine.numSpeakers())throw new IOException("Sprecher nicht verfügbar");
    return engine.generate(text,sid,Math.max(.35f,Math.min(2.5f,rate/pitch)));
  }
  static void remove(File f){if(f.isDirectory()){File[] fs=f.listFiles();if(fs!=null)for(File child:fs)remove(child);}f.delete();}
}
