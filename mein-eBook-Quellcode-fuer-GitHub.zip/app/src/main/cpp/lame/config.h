#ifndef EBOOK_LAME_CONFIG_H
#define EBOOK_LAME_CONFIG_H
typedef float ieee754_float32_t;
typedef double ieee754_float64_t;
#define STDC_HEADERS 1
#define HAVE_STDINT_H 1
#define HAVE_INTTYPES_H 1
#define HAVE_STDLIB_H 1
#define HAVE_STRING_H 1
#define HAVE_ERRNO_H 1
#define HAVE_FCNTL_H 1
#define HAVE_LIMITS_H 1
#define HAVE_UNISTD_H 1
#define HAVE_MEMCPY 1
#define HAVE_STRCHR 1
#define HAVE_STRERROR 1
#define HAVE_LONG_DOUBLE 1
#define HAVE_LONG_DOUBLE_WIDER 1
#define HAVE_STRCASECMP 1
#define HAVE_STRNCASECMP 1
#define HAVE_LOG10 1
#define HAVE_FABSF 1
#define TAKEHIRO_IEEE754_HACK 1
#define IEEE754_FLOAT32_T float
#define IEEE754_FLOAT64_T double
#define HAVE_IEEE754_FLOAT32_T 1
#define HAVE_IEEE754_FLOAT64_T 1
#define PACKAGE "lame"
#define PACKAGE_VERSION "3.100"
#define VERSION "3.100"

#endif
