// Local KittenTTS 2 Mini inference. The pinned runtime is already bundled by sherpa.
#include <jni.h>
#include <dlfcn.h>
#include <algorithm>
#include <cmath>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>
#include "onnxruntime_c_api.h"

static const OrtApi *api=nullptr;
static void check(OrtStatus *s) { if(s) {std::string m=api->GetErrorMessage(s);api->ReleaseStatus(s);throw std::runtime_error(m);} }
static std::string str(JNIEnv *env,jstring s) {const char *p=env->GetStringUTFChars(s,nullptr);std::string v(p);env->ReleaseStringUTFChars(s,p);return v;}
static void error(JNIEnv *env,const std::exception &e) {env->ThrowNew(env->FindClass("java/io/IOException"),e.what());}
struct Model {
 OrtEnv *env=nullptr;OrtSession *session=nullptr;OrtMemoryInfo *memory=nullptr;
 ~Model(){if(memory)api->ReleaseMemoryInfo(memory);if(session)api->ReleaseSession(session);if(env)api->ReleaseEnv(env);}
};
static void runtime() {
 if(api)return;
 void *lib=dlopen("libonnxruntime.so",RTLD_NOW|RTLD_LOCAL);
 if(!lib)throw std::runtime_error("Offline-Sprachlaufzeit fehlt.");
 auto base=reinterpret_cast<const OrtApiBase *(*)()>(dlsym(lib,"OrtGetApiBase"));
 if(!base||(api=base()->GetApi(ORT_API_VERSION))==nullptr)throw std::runtime_error("Offline-Sprachlaufzeit ist inkompatibel.");
}
extern "C" JNIEXPORT jlong JNICALL Java_de_meinebook_app_KittenSpeech_open(JNIEnv *e,jclass,jstring path) {
 try {runtime();auto m=std::make_unique<Model>();check(api->CreateEnv(ORT_LOGGING_LEVEL_WARNING,"ebook-studio",&m->env));
 OrtSessionOptions *options=nullptr;check(api->CreateSessionOptions(&options));
 try {check(api->SetIntraOpNumThreads(options,2));check(api->SetInterOpNumThreads(options,1));check(api->SetSessionGraphOptimizationLevel(options,ORT_ENABLE_ALL));check(api->CreateSession(m->env,str(e,path).c_str(),options,&m->session));}
 catch(...){api->ReleaseSessionOptions(options);throw;}api->ReleaseSessionOptions(options);
 check(api->CreateCpuMemoryInfo(OrtArenaAllocator,OrtMemTypeDefault,&m->memory));return reinterpret_cast<jlong>(m.release());
 } catch(const std::exception &ex){error(e,ex);return 0;}
}
extern "C" JNIEXPORT void JNICALL Java_de_meinebook_app_KittenSpeech_release(JNIEnv *,jclass,jlong ptr){delete reinterpret_cast<Model*>(ptr);}
extern "C" JNIEXPORT jfloatArray JNICALL Java_de_meinebook_app_KittenSpeech_infer(JNIEnv *e,jclass,jlong ptr,jlongArray input,jfloatArray style,jfloat speed) {
 OrtValue *values[3]={},*outputs[2]={};OrtTensorTypeAndShapeInfo *shape=nullptr;
 try {
  auto m=reinterpret_cast<Model*>(ptr);if(!m)throw std::runtime_error("Sprachmodell ist geschlossen.");
  int n=e->GetArrayLength(input);if(n<4||n>510||e->GetArrayLength(style)!=256||!std::isfinite(speed)||speed<.35f||speed>2.5f)throw std::runtime_error("Ungültige Sprachparameter.");
  std::vector<int64_t> ids(n);std::vector<float> styles(256);e->GetLongArrayRegion(input,0,n,reinterpret_cast<jlong*>(ids.data()));e->GetFloatArrayRegion(style,0,256,styles.data());
  int64_t dims[2]={1,n},sdims[2]={1,256},one[1]={1};
  check(api->CreateTensorWithDataAsOrtValue(m->memory,ids.data(),n*sizeof(int64_t),dims,2,ONNX_TENSOR_ELEMENT_DATA_TYPE_INT64,&values[0]));
  check(api->CreateTensorWithDataAsOrtValue(m->memory,styles.data(),256*sizeof(float),sdims,2,ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT,&values[1]));
  check(api->CreateTensorWithDataAsOrtValue(m->memory,&speed,sizeof(float),one,1,ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT,&values[2]));
  const char *names[3]={"input_ids","style","speed"},*outnames[2]={"waveform","durations"};
  check(api->Run(m->session,nullptr,names,values,3,outnames,2,outputs));
  check(api->GetTensorTypeAndShape(outputs[0],&shape));size_t count=0;check(api->GetTensorShapeElementCount(shape,&count));api->ReleaseTensorTypeAndShapeInfo(shape);shape=nullptr;
  if(count==0||count>24000*120)throw std::runtime_error("Ungültige Länge der Sprachausgabe.");
  float *wav=nullptr;int64_t *dur=nullptr;check(api->GetTensorMutableData(outputs[0],reinterpret_cast<void**>(&wav)));check(api->GetTensorMutableData(outputs[1],reinterpret_cast<void**>(&dur)));
  check(api->GetTensorTypeAndShape(outputs[1],&shape));size_t durations=0;check(api->GetTensorShapeElementCount(shape,&durations));api->ReleaseTensorTypeAndShapeInfo(shape);shape=nullptr;
  if(durations!=static_cast<size_t>(n))throw std::runtime_error("Ungültige Sprachdauer.");
  int64_t total=0;for(int i=0;i<n;i++)total+=std::max<int64_t>(0,dur[i]);
  size_t frame=std::max<size_t>(1,std::llround(static_cast<double>(count)/std::max<int64_t>(1,total)));
  size_t tail=std::max<int64_t>(0,dur[n-1]-1)*frame;if(tail+frame<count)count-=tail;
  size_t fade=std::min<size_t>(120,count/8);std::vector<float> audio(count);
  for(size_t i=0;i<count;i++){if(!std::isfinite(wav[i]))throw std::runtime_error("Ungültige Audiodaten.");audio[i]=std::clamp(wav[i],-1.f,1.f);if(i<fade)audio[i]*=static_cast<float>(i)/std::max<size_t>(1,fade-1);if(count-1-i<fade)audio[i]*=static_cast<float>(count-1-i)/std::max<size_t>(1,fade-1);}
  auto result=e->NewFloatArray(count);if(result)e->SetFloatArrayRegion(result,0,count,audio.data());
  for(auto v:values)if(v)api->ReleaseValue(v);for(auto v:outputs)if(v)api->ReleaseValue(v);return result;
 }catch(const std::exception &ex){if(shape)api->ReleaseTensorTypeAndShapeInfo(shape);for(auto v:values)if(v)api->ReleaseValue(v);for(auto v:outputs)if(v)api->ReleaseValue(v);error(e,ex);return nullptr;}
}
static std::string phonemeData;
extern "C" JNIEXPORT void JNICALL Java_de_meinebook_app_KittenSpeech_resetPhonemizer(JNIEnv *,jclass){phonemeData.clear();}
extern "C" JNIEXPORT jstring JNICALL Java_de_meinebook_app_KittenSpeech_phonemize(JNIEnv *e,jclass,jstring data,jstring text) {
 try {
  static void *lib=dlopen("libsherpa-onnx-jni.so",RTLD_NOW|RTLD_LOCAL);if(!lib)throw std::runtime_error("Lautschrift-Laufzeit fehlt.");
  auto init=reinterpret_cast<int(*)(int,int,const char*,int)>(dlsym(lib,"espeak_Initialize"));
  auto voice=reinterpret_cast<int(*)(const char*)>(dlsym(lib,"espeak_SetVoiceByName"));
  auto phonemes=reinterpret_cast<const char *(*)(const void **,int,int)>(dlsym(lib,"espeak_TextToPhonemes"));
  if(!init||!voice||!phonemes)throw std::runtime_error("Lautschrift-Schnittstelle fehlt.");
  std::string dir=str(e,data),value=str(e,text);if(phonemeData!=dir){if(init(2,0,dir.c_str(),0)<=0)throw std::runtime_error("Lautschrift konnte nicht geladen werden.");phonemeData=dir;}if(voice("de")!=0)throw std::runtime_error("Deutsche Lautschrift konnte nicht geladen werden.");
  const void *p=value.c_str();std::string out;
  while(p){const char *s=phonemes(&p,1,2|0x80|('^'<<8));if(s){if(!out.empty())out+=' ';out+=s;}}
  return e->NewStringUTF(out.c_str());
 }catch(const std::exception &ex){error(e,ex);return nullptr;}
}
