#include <jni.h>
#include <stdint.h>
#include <stdlib.h>
#include "lame.h"
static jbyteArray result(JNIEnv *env,unsigned char *b,int n){
 if(n<0){(*env)->ThrowNew(env,(*env)->FindClass(env,"java/lang/IllegalStateException"),"MP3 encoding failed");return NULL;}
 jbyteArray out=(*env)->NewByteArray(env,n);if(out&&n)(*env)->SetByteArrayRegion(env,out,0,n,(jbyte*)b);return out;
}
JNIEXPORT jlong JNICALL Java_de_meinebook_app_Mp3Encoder_open(JNIEnv *env,jclass cls,jint rate){
 lame_t g=lame_init();if(!g)return 0;lame_set_in_samplerate(g,rate);lame_set_num_channels(g,1);lame_set_mode(g,MONO);lame_set_brate(g,64);lame_set_quality(g,2);lame_set_bWriteVbrTag(g,0);
 if(lame_init_params(g)<0){lame_close(g);return 0;}return (jlong)(intptr_t)g;
}
JNIEXPORT jbyteArray JNICALL Java_de_meinebook_app_Mp3Encoder_encode(JNIEnv *env,jclass cls,jlong ptr,jshortArray input){
 int n=(*env)->GetArrayLength(env,input);int capacity=n*5/4+7200;unsigned char *out=malloc(capacity);if(!out){(*env)->ThrowNew(env,(*env)->FindClass(env,"java/lang/OutOfMemoryError"),"MP3 buffer");return NULL;}
 jshort *pcm=(*env)->GetShortArrayElements(env,input,NULL);if(!pcm){free(out);return NULL;}
 int count=lame_encode_buffer((lame_t)(intptr_t)ptr,pcm,pcm,n,out,capacity);(*env)->ReleaseShortArrayElements(env,input,pcm,JNI_ABORT);
 jbyteArray r=result(env,out,count);free(out);return r;
}
JNIEXPORT jbyteArray JNICALL Java_de_meinebook_app_Mp3Encoder_finish(JNIEnv *env,jclass cls,jlong ptr){unsigned char out[7200];int n=lame_encode_flush((lame_t)(intptr_t)ptr,out,sizeof(out));return result(env,out,n);}
JNIEXPORT void JNICALL Java_de_meinebook_app_Mp3Encoder_destroy(JNIEnv *env,jclass cls,jlong ptr){lame_close((lame_t)(intptr_t)ptr);}
