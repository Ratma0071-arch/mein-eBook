/* Shared speech planning for live playback and MP3 export. No text leaves this device. */
(()=>{
 'use strict';
 const $=id=>document.getElementById(id), synth=window.speechSynthesis;
 const PRESETS={
  narrator:{name:'Erzähler',rate:1,pitch:1,mood:'normal'},
  andre:{name:'André',rate:1.08,pitch:1.04,mood:'joy'},
  mike:{name:'Mike',rate:.95,pitch:.94,mood:'normal'},
  rene:{name:'René',rate:1.04,pitch:1.06,mood:'joy'},
  michael:{name:'Michael',rate:.94,pitch:.98,mood:'normal'},
  thomas:{name:'Thomas',rate:.9,pitch:1.02,mood:'normal'}
 };
 const ALIASES={andre:'andre','andré':'andre',mike:'mike',rene:'rene','rené':'rene',michael:'michael',thomas:'thomas','erzähler':'narrator',narrator:'narrator'};
 const KEYS={state:'meinebook.studio.v2',profiles:'lesestimme.voiceprofiles.v1'};
 let voices=[],cast={},profiles={},downloading=false,exporting=false;
 function read(key){try{return JSON.parse(localStorage.getItem(key)||'{}')||{}}catch{return {}}}
 const saved=read(KEYS.state);cast=saved.cast||{};profiles=read(KEYS.profiles);
 function message(s){$('offlineStatus').textContent=s;}
 function state(){return {language:$('language').value,voiceSource:$('voiceSource').value,gender:$('gender').value,voice:current()?.voiceURI||'',character:$('character').value,ageTone:$('ageTone').value,autoRoles:$('autoRoles').checked,cast};}
 function persist(){localStorage.setItem(KEYS.state,JSON.stringify(state()));}
 function current(){return $('voice').value===''?null:voices[Number($('voice').value)]||null;}
 function byUri(uri){return voices.find(v=>v.voiceURI===uri);}
 function info(){
  const v=current();$('downloadVoice').disabled=downloading||!v?.neural||v.installed;
  $('downloadVoice').textContent=v?.installed?'✓ Stimme verfügbar':'⬇ KI-Stimme herunterladen';
  $('voiceInfo').textContent=!v?'Keine passende Stimme verfügbar. Wähle eine andere Stimme oder installiere eine Offline-Gerätestimme.':v.neural?(v.installed?'Lokale KI-Stimme installiert.':`Einmaliger Download: ${Math.ceil(v.bytes/1000000)} MB. Danach offline nutzbar.`):'Offline-Gerätestimme. Geschlecht und Qualität hängen vom Anbieter ab.';
 }
 function refresh(wanted){
  const previous=typeof wanted==='string'?wanted:current()?.voiceURI||saved.voice;
  voices=synth?.getVoices()||[];const lang=$('language').value.slice(0,2),source=$('voiceSource').value,gender=$('gender').value;
  $('voice').replaceChildren();
  voices.forEach((v,i)=>{
   if(v.lang.slice(0,2)!==lang||((source==='neural')!==!!v.neural))return;
   if(v.neural&&gender!=='all'&&v.gender!==gender)return;
   const o=document.createElement('option');o.value=String(i);o.textContent=v.name+' · '+v.lang+(v.neural?(v.gender==='female'?' · weiblich':' · männlich'):'')+(v.installed?' ✓':' · Download');$('voice').append(o);
  });
  if(!$('voice').options.length){const o=document.createElement('option');o.value='';o.textContent='Keine passende Stimme';$('voice').append(o);}
  const match=[...$('voice').options].find(o=>voices[Number(o.value)]?.voiceURI===previous);
  if(match)$('voice').value=match.value;info();
 }
 function settings(){return {voice:current()?.voiceURI||'',lang:$('language').value,mood:$('mood').value,rate:Number($('rate').value),pitch:Number($('pitch').value),volume:Number($('vol').value),ageTone:$('ageTone').value,pause:Number($('pause').value)};}
 function apply(p){
  if(p.lang)$('language').value=p.lang;
  const uri=typeof p.voice==='string'?p.voice:p.voice?.uri;
  const v=byUri(uri)||voices.find(v=>p.voice&&v.name===p.voice.name&&v.lang===p.voice.lang);
  if(v){$('voiceSource').value=v.neural?'neural':'device';$('gender').value='all';refresh(v.voiceURI);}else refresh();
  for(const id of ['rate','pitch','pause','mood'])if(p[id]!==undefined){$(id).value=String(p[id]);$(id).dispatchEvent(new Event('input'));}
  if(p.volume!==undefined||p.vol!==undefined){$('vol').value=String(p.volume??p.vol);$('vol').dispatchEvent(new Event('input'));}
  $('ageTone').value=p.ageTone||'natural';persist();
 }
 function applyCharacter(){
  const role=$('character').value;if(cast[role]){apply(cast[role]);return;}
  const p=PRESETS[role];apply({...settings(),rate:p.rate,pitch:p.pitch,mood:p.mood});
 }
 function labelledSpeaker(text){const m=text.match(/^\s*(Andr[eé]|Mike|Ren[eé]|Michael|Thomas|Erzähler|Narrator)\s*:/iu);return m?ALIASES[m[1].toLowerCase()]:null;}
 function plan(item){
  let p=settings(),role=$('autoRoles').checked?item.speaker:null;
  if(role){
   const assigned=cast[role];if(assigned)p={...p,...assigned};
   else {
    const preset=PRESETS[role];p={...p,rate:preset.rate,pitch:preset.pitch,mood:preset.mood};
    // Default character base is male; explicitly assigned voices always win.
    const male=voices.find(v=>v.neural===current()?.neural&&v.lang.slice(0,2)===p.lang.slice(0,2)&&v.gender==='male'&&v.installed);
    if(role!=='narrator'&&male)p.voice=male.voiceURI;
   }
  }
  const v=byUri(p.voice);if(!v)throw Error('Bitte eine Stimme auswählen.');
  if(v.installed===false)throw Error('Bitte die KI-Stimme „'+v.name+'“ zuerst herunterladen.');
  const text=item.text.replace(/^\s*(Andr[eé]|Mike|Ren[eé]|Michael|Thomas|Erzähler|Narrator)\s*:\s*/iu,'');
  if(!text.trim())throw Error('Sprecherzeile enthält keinen Text.');
  let rate=Number(p.rate),pitch=Number(p.pitch),volume=Number(p.volume),mood=p.mood;
  if(mood==='auto')mood=/[!]\s*$/.test(text)?'joy':/(flüster|leise)/iu.test(text)?'whisper':/(traurig|weinte)/iu.test(text)?'sad':'normal';
  const effects={joy:[1.06,1.04,1],anger:[1.08,.96,1],sad:[.9,.96,.9],whisper:[.9,1,.55],sensual:[.9,.98,.85],laugh:[1.08,1.06,1]};
  const e=effects[mood]||[1,1,1];rate*=e[0];pitch*=e[1];volume*=e[2];
  if(p.ageTone==='young'){pitch*=1.08;rate*=1.03;}if(p.ageTone==='mature'){pitch*=.93;rate*=.94;}
  return {text,voice:v.voiceURI,voiceObject:v,lang:v.lang,rate:Math.max(.5,Math.min(1.6,rate)),pitch:Math.max(.75,Math.min(1.35,pitch)),volume:Math.max(0,Math.min(1,volume))};
 }
 function refreshProfiles(){const prev=$('profile').value;$('profile').innerHTML='<option value="">Profil auswählen</option>';Object.keys(profiles).sort((a,b)=>a.localeCompare(b,'de')).forEach(name=>{const o=document.createElement('option');o.value=name;o.textContent=name;$('profile').append(o);});if(profiles[prev])$('profile').value=prev;}
 for(const id of ['language','voiceSource','gender'])$(id).addEventListener('change',()=>{synth?.cancel();refresh();persist();});
 $('voice').addEventListener('change',()=>{info();persist();});$('character').addEventListener('change',applyCharacter);$('ageTone').addEventListener('change',persist);$('autoRoles').addEventListener('change',persist);
 $('assignCharacter').onclick=()=>{cast[$('character').value]=settings();persist();message('Stimme für '+PRESETS[$('character').value].name+' gespeichert.');};
 $('downloadVoice').onclick=()=>{
  const v=current();if(!v?.neural||!window.AndroidBridge||downloading)return;
  downloading=true;info();message('Download gestartet. Nur das Stimmenpaket wird geladen.');AndroidBridge.downloadVoice(v.id);
 };
 $('pinShortcut').onclick=()=>window.AndroidBridge?.pinShortcut();
 $('saveProfile').onclick=()=>{const name=$('profileName').value.trim();if(!name)return message('Bitte einen Profilnamen eingeben.');profiles[name]=settings();localStorage.setItem(KEYS.profiles,JSON.stringify(profiles));refreshProfiles();$('profile').value=name;message('Profil gespeichert.');};
 $('profile').onchange=()=>{const p=profiles[$('profile').value];if(p){$('profileName').value=$('profile').value;apply(p);}};
 $('deleteProfile').onclick=()=>{const name=$('profile').value;if(!name)return;delete profiles[name];localStorage.setItem(KEYS.profiles,JSON.stringify(profiles));refreshProfiles();message('Profil gelöscht.');};
 const samples={'de':'Hallo! Ich lese dein Buch mit einer lokalen Stimme.','en':'Hello! I am reading your book with a local voice.','fr':'Bonjour ! Je lis votre livre avec une voix locale.','it':'Ciao! Leggo il tuo libro con una voce locale.','es':'¡Hola! Leo tu libro con una voz local.'};
 $('testVoice').onclick=()=>{try{if(exporting)throw Error('Bitte zuerst den MP3-Export beenden.');synth.cancel();const p=plan({text:samples[$('language').value.slice(0,2)],speaker:null});const u=new SpeechSynthesisUtterance(p.text);Object.assign(u,{voice:p.voiceObject,lang:p.lang,rate:p.rate,pitch:p.pitch,volume:p.volume});u.onerror=e=>message(e.error||'Stimmenfehler');synth.speak(u);}catch(e){message(e.message);}};
 $('exportProfiles').onclick=()=>{const blob=new Blob([JSON.stringify({format:'lesestimme-profiles-v2',profiles,cast},null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='meinebook-stimmenprofile.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),2000);};
 $('importProfiles').onchange=async e=>{try{const f=e.target.files[0];if(!f)return;if(f.size>200000)throw Error('Profildatei zu groß.');const d=JSON.parse(await f.text());if(!['lesestimme-profiles-v1','lesestimme-profiles-v2'].includes(d.format))throw Error('Unbekanntes Profilformat.');
  for(const [name,p] of Object.entries(d.profiles||{}))if(name.length<=60&&p&&Number.isFinite(Number(p.rate))&&Number.isFinite(Number(p.pitch)))profiles[name]=p;
  for(const role of Object.keys(PRESETS))if(d.cast?.[role])cast[role]=d.cast[role];localStorage.setItem(KEYS.profiles,JSON.stringify(profiles));persist();refreshProfiles();message('Profile importiert.');
 }catch(err){message('Import: '+err.message);}};
 $('exportAudio').onclick=()=>{if(exporting)return;try{if(!window.AndroidBridge)throw Error('MP3-Export ist in der Android-App verfügbar.');const {plan:parts,name}=window.EBookExport();exporting=true;$('exportAudio').disabled=true;$('cancelExport').disabled=false;$('exportStatus').textContent='Speicherort für die MP3-Datei wählen …';AndroidBridge.exportAudio(JSON.stringify(parts),name);}catch(e){exportStatus(e.message,true);}};
 $('cancelExport').onclick=()=>{AndroidBridge.cancelAudioExport();$('exportStatus').textContent='Abbruch nach dem aktuellen Textabschnitt …';};
 function exportStatus(msg,done){$('exportStatus').textContent=msg;if(done){exporting=false;$('exportAudio').disabled=false;$('cancelExport').disabled=true;}}
 window.VoiceStudio={refresh,plan,labelledSpeaker,exportStatus,downloadStatus(msg,done){message(msg);if(done){downloading=false;refresh();}}};
 for(const id of ['language','voiceSource','gender','character','ageTone'])if(saved[id]&&[...$(id).options].some(o=>o.value===saved[id]))$(id).value=saved[id];
 if(saved.autoRoles!==undefined)$('autoRoles').checked=!!saved.autoRoles;
 refresh(saved.voice);refreshProfiles();
})();
