/* Conservative, local dialogue attribution. Unknown speakers never alternate randomly. */
(()=>{
 const base=[
  ['andre','André','male','young'],['mike','Mike','male','young'],['rene','René','male','young'],['michael','Michael','male','young'],['thomas','Thomas','male','young'],
  ['nicole','Nicole','female','young'],['andrea','Andrea','female','adult'],['brigitte','Brigitte','female','adult'],['maria','Maria','female','adult'],['margarete','Margarete','female','mature'],['ruth','Ruth','female','mature'],['mia','Mia','female','child'],
  ['miguel','Miguel','male','child'],['johannes','Johannes','male','child'],['marco','Marco','male','young'],['giovanni','Giovanni','male','young'],['luca','Luca','male','young'],['alessandro','Alessandro','male','young'],['fabio','Fabio','male','young'],['luciano','Luciano','male','young'],
  ['wolfgang','Wolfgang','male','adult'],['lothar','Lothar','male','adult'],['wilhelm','Wilhelm','male','mature'],
  ['female','Frau / Mädchen (unbekannter Name)','female','natural'],['male','Mann / Junge (unbekannter Name)','male','natural']
 ];
 const displayNames={andrea:'Andrea Schwarz',margarete:'Margarete Schwarz',wolfgang:'Wolfgang Gärtner',maria:'Maria Gärtner'};
 let custom=[];try{custom=JSON.parse(localStorage.getItem('meinebook.people.v1')||'[]');if(!Array.isArray(custom))custom=[];}catch{}
 let overrides={};try{overrides=JSON.parse(localStorage.getItem('meinebook.dialogue.overrides.v1')||'{}')||{};}catch{}
 let narrators={};try{narrators=JSON.parse(localStorage.getItem('meinebook.chapterNarrators.v1')||'{}')||{};}catch{}
 let lastItems=[],lastChapter='',recent=[];
 function fingerprint(text){let h=2166136261;for(let i=0;i<text.length;i++){h^=text.charCodeAt(i);h=Math.imul(h,16777619)}return (h>>>0).toString(36)+':'+text.length;}
 function people(){return [...base.map(([id,name,gender,age])=>({id,name,displayName:displayNames[id]||name,gender,age})),...custom.map(p=>({...p,displayName:p.name}))];}
 function person(id){return people().find(p=>p.id===id)||null;}
 const esc=s=>s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
 function namePattern(p){const baseName=esc(p.name).replace(/é/g,'[eé]'),suffix=p.displayName&&p.displayName!==p.name?p.displayName.slice(p.name.length).trim():'';return baseName+(suffix?'(?:\\s+'+esc(suffix)+')?':'');}
 function labelled(text){for(const p of people()){if(['female','male'].includes(p.id))continue;if(new RegExp('^\\s*'+namePattern(p)+'\\s*:','iu').test(text))return p.id;}return null;}
 const verb='(?:sagte|sagt|fragte|fragt|rief|ruft|antwortete|antwortet|flüsterte|flüstert|murmelte|murmelt|erwiderte|erwidert|schrie|schreit|meinte|meint|said|says|asked|asks|whispered|replied|shouted|dit|demanda|répondit|chuchota|disse|chiese|rispose|sussurrò|dijo|preguntó|respondió|susurró)';
 function attribute(context,direction){
  const matches=[];
  for(const p of people()){
   if(['female','male'].includes(p.id))continue;
   const n=namePattern(p),space='[\\s,;:!?.-]{0,12}';
   const regexes=direction==='before'?[new RegExp('(?<![\\p{L}])'+n+'\\s+(?:(?:leise|laut|lächelnd|traurig|softly|quietly)\\s+)?'+verb+'[^.!?„“”"»«]{0,35}$','iu')]:[new RegExp('^[\\s,;:!?.-]{0,12}'+verb+'\\s+(?:(?:leise|laut|lächelnd|traurig|softly|quietly)\\s+)?'+n+'(?![\\p{L}])','iu'),new RegExp('^'+space+n+'\\s+'+verb+'(?![\\p{L}])','iu')];
   if(regexes.some(r=>r.test(context)))matches.push(p.id);
  }
  if(matches.length===1)return matches[0];if(matches.length>1)return null;
  const female='(?:die Frau|das Mädchen|die Mutter|the woman|the girl|la femme|la fille|la donna|la ragazza|la mujer|la chica)';
  const male='(?:der Mann|der Junge|der Vater|the man|the boy|l’homme|le garçon|l’uomo|il ragazzo|el hombre|el chico)';
  for(const [id,noun] of [['female',female],['male',male]]){
   const r=direction==='before'?new RegExp(noun+'\\s+'+verb+'[^.!?„“”"»«]{0,30}$','iu'):new RegExp('^[\\s,;:!?.-]{0,12}'+verb+'\\s+'+noun+'(?![\\p{L}])','iu');
   if(r.test(context))return id;
  }return null;
 }
 function mood(text){
  if(/flüster|hauchte|chuchot|sussurr|susurr|whisper/iu.test(text))return 'whisper';
  if(/traurig|weinte|schluchz|triste|pleur|piang|llor|sobbed|sadly/iu.test(text))return 'sad';
  if(/wütend|zornig|schrie|schreit|angrily|furious|furieux|furiosa|enfadad|gritó/iu.test(text))return 'anger';
  if(/fröhlich|jubel|lachte|lächel|joyfully|laughed|heureu|sorrise|felice|sonrió|alegre/iu.test(text))return 'joy';
  return null;
 }
 function split(text){
  const list=[];
  function add(text,speaker,hint){
   const chunks=text.match(/[^.!?…]+(?:[.!?…]+[”"'»«“]?|$)/gu)||[text];
   for(let chunk of chunks){chunk=chunk.trim();while(chunk.length>230){let cut=chunk.lastIndexOf(' ',220);if(cut<60)cut=220;list.push({text:chunk.slice(0,cut).trim(),speaker,mood:hint,para:false});chunk=chunk.slice(cut).trim();}if(chunk)list.push({text:chunk,speaker,mood:hint,para:false});}
  }
  for(const raw of text.split(/\n+/)){
   const p=raw.trim();if(!p)continue;const label=labelled(p);
   if(label){add(p,label,mood(p));list[list.length-1].para=true;continue;}
   const quoted=[...p.matchAll(/„[^“]*“|“[^”]*”|»[^«]*«|«[^»]*»|"[^"\n]+"/gu)];let cursor=0;
   for(const match of quoted){
    const start=match.index,end=start+match[0].length,before=p.slice(Math.max(cursor,start-110),start),after=p.slice(end,end+110);
    const role=attribute(after,'after')||attribute(before,'before');
    if(start>cursor)add(p.slice(cursor,start),null,null);
    add(match[0],role,mood(after.slice(0,75))||mood(before)||mood(match[0]));cursor=end;
   }
   if(cursor<p.length)add(p.slice(cursor),null,null);
   if(!quoted.length&&cursor===0){/* add above handles ordinary narration */}
   if(list.length)list[list.length-1].para=true;
  }
  lastChapter=fingerprint(text);list.forEach((item,i)=>{item.chapterKey=lastChapter;item.itemIndex=i;const forced=overrides[lastChapter+':'+i];item.manualSpeaker=!!forced;if(forced)item.speaker=forced;});lastItems=list.map(item=>({...item}));recent=recent.filter(x=>x.chapterKey!==lastChapter);recent.unshift({chapterKey:lastChapter,items:lastItems.map(item=>({...item}))});recent=recent.slice(0,40);return list;
 }
 function addPerson(name,gender,age){name=name.trim();if(!/^[\p{L}][\p{L} .’-]{0,49}$/u.test(name))throw Error('Bitte einen Namen mit höchstens 50 Zeichen eingeben.');if(!['male','female'].includes(gender))throw Error('Stimmtyp fehlt.');
  const id='person:'+name.toLocaleLowerCase('de');custom=custom.filter(p=>p.id!==id);custom.push({id,name,gender,age});localStorage.setItem('meinebook.people.v1',JSON.stringify(custom));return id;}
 function setSpeaker(index,speaker,chapterKey=lastChapter){const entry=recent.find(x=>x.chapterKey===chapterKey);if(!entry||!Number.isInteger(index)||index<0||index>=entry.items.length)throw Error('Textstelle ist nicht mehr aktuell.');const key=chapterKey+':'+index;if(!speaker)delete overrides[key];else if(speaker==='narrator'||person(speaker))overrides[key]=speaker;else throw Error('Unbekannte Figur.');localStorage.setItem('meinebook.dialogue.overrides.v1',JSON.stringify(overrides));}
 function setNarrator(chapterKey,role){if(!chapterKey)throw Error('Kapitel ist nicht geladen.');if(!['','narrator','andre','mike'].includes(role))throw Error('Diese Erzählerwahl ist nicht erlaubt.');if(role)narrators[chapterKey]=role;else delete narrators[chapterKey];localStorage.setItem('meinebook.chapterNarrators.v1',JSON.stringify(narrators));}
 function chapterNarrator(chapterKey){return narrators[chapterKey]||'';}
 function lastSplit(texts){let found;if(Array.isArray(texts))found=recent.find(entry=>entry.items.length===texts.length&&entry.items.every((item,i)=>item.text.trim()===String(texts[i]).trim()));const entry=found||{chapterKey:lastChapter,items:lastItems};return {chapterKey:entry.chapterKey,items:entry.items.map(item=>({...item}))};}
 window.DialogueParser={people,person,labelled,split,mood,addPerson,setSpeaker,setNarrator,chapterNarrator,lastSplit};
})();
