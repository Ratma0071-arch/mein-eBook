(()=>{
 const $=id=>document.getElementById(id);
 function view(name){document.querySelectorAll('main>.page').forEach(el=>el.hidden=el.id!=='view-'+name);document.querySelectorAll('.appNav button').forEach(el=>{const on=el.dataset.view===name;el.classList.toggle('active',on);el.setAttribute('aria-current',on?'page':'false')});window.scrollTo({top:0,behavior:'smooth'});}
 document.querySelectorAll('.appNav button').forEach(el=>el.onclick=()=>{if(el.dataset.view==='text'&&$('editText').disabled)window.ManualBook();view(el.dataset.view)});
 $('newText').onclick=()=>{window.ManualBook();view('text');$('editText').focus();};
 const drop=$('file');drop.addEventListener('change',()=>view('read'));
 $('language').addEventListener('change',()=>{$('editText').lang=$('language').value.slice(0,2)});
 window.AppUpdates={status(msg){$('updateStatus').textContent=msg;$('checkUpdates').disabled=false;}};
 $('checkUpdates').onclick=()=>{if(!window.AndroidBridge){$('updateStatus').textContent='Update-Prüfung ist in der Android-App verfügbar.';return;}$('checkUpdates').disabled=true;$('updateStatus').textContent='GitHub-Releases werden geprüft …';AndroidBridge.checkUpdates();};
 $('openUpdates').onclick=()=>window.AndroidBridge?.openUpdatePage();
 view('read');
})();
