// Exercise actual handlers using a small DOM adapter; Android tests cover the real WebView.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const root=path.join(__dirname,'../app/src/main/assets'),values=new Map(),elements=new Map();
class Element {constructor(){this.value='';this.options=[];this.dataset={};this.classList={contains:()=>false};}setAttribute(){}append(...x){this.options.push(...x)}insertBefore(){}before(){}addEventListener(){}replaceChildren(){}querySelector(){return new Element()}querySelectorAll(){return []}}
const get=id=>{if(!elements.has(id))elements.set(id,new Element());return elements.get(id)};
const localStorage={getItem:k=>values.has(k)?values.get(k):null,setItem:(k,v)=>values.set(k,String(v)),removeItem:k=>values.delete(k)};
let exported;
const context={localStorage,console,setTimeout:()=>{},Event:class{},Option:class{constructor(text,value){this.text=text;this.value=value}},MutationObserver:class{observe(){}},location:{reload(){}},document:{getElementById:get,createElement:()=>new Element(),querySelector:()=>new Element(),head:new Element()},VoiceStudio:{directory:()=>[]},AndroidBridge:{saveSettings:value=>{exported=JSON.parse(value)}}};context.window=context;
vm.createContext(context);vm.runInContext(fs.readFileSync(path.join(root,'dialogue.js'),'utf8'),context);vm.runInContext(fs.readFileSync(path.join(root,'character-tools.js'),'utf8'),context);
async function importData(data){await get('characterBackupFile').onchange({target:{files:[{size:Buffer.byteLength(JSON.stringify(data)),text:async()=>JSON.stringify(data)}],value:''}})}
(async()=>{
 const parser=context.DialogueParser,items=parser.split('André sagte: „Guten Morgen.“'),chapter=items[0].chapterKey;
 parser.setSpeaker(0,'mike',chapter);parser.setNarrator(chapter,'andre');
 localStorage.setItem('lesestimme.voiceprofiles.v1',JSON.stringify({Maximum:{voice:'neural:test',pitch:1.55,rate:1,volume:1}}));
 localStorage.setItem('meinebook.manualDraft','PRIVATE SENTINEL');
 get('exportCharacterData').onclick();assert(exported);assert(!JSON.stringify(exported).includes('PRIVATE SENTINEL'));
 const key=Object.keys(exported.dialogueOverrides)[0];assert.match(key,/^[a-z0-9]+:\d+:\d+$/);
 localStorage.setItem('meinebook.dialogue.overrides.v1',JSON.stringify({'keep:1:0':'thomas'}));
 await importData(exported);assert.equal(JSON.parse(localStorage.getItem('meinebook.dialogue.overrides.v1'))[key],'mike');assert.equal(JSON.parse(localStorage.getItem('meinebook.dialogue.overrides.v1'))['keep:1:0'],'thomas');assert.equal(JSON.parse(localStorage.getItem('lesestimme.voiceprofiles.v1')).Maximum.pitch,1.55);
 const before=JSON.stringify([...values]);await importData({...exported,dialogueOverrides:{'bad:2':'mike'}});assert.equal(JSON.stringify([...values]),before);assert.match(get('characterSummary').textContent,/nicht eingelesen/);
 await importData({...exported,profiles:{Invalid:{pitch:9}}});assert.equal(JSON.stringify([...values]),before);
 console.log('PASS: real dialogue keys, maximum pitch, merge, invalid input without writes, native export, private text excluded');
})().catch(error=>{console.error(error);process.exitCode=1});
