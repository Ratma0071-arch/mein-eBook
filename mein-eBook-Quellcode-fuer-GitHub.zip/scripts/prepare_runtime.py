"""Fetch the pinned official Android neural speech runtime, checking its digest."""
import hashlib
import pathlib
import urllib.request

target = pathlib.Path('app/libs/sherpa-onnx-1.12.17.aar')
digest = '96853e39b5b93f90c7d161cace8eb0898339c7dd6017c9f92975cb330e9d66fd'
if not target.exists() or hashlib.sha256(target.read_bytes()).hexdigest() != digest:
    target.parent.mkdir(parents=True, exist_ok=True)
    url = 'https://github.com/k2-fsa/sherpa-onnx/releases/download/v1.12.17/sherpa-onnx-1.12.17.aar'
    with urllib.request.urlopen(url, timeout=120) as response:
        data = response.read()
    if hashlib.sha256(data).hexdigest() != digest:
        raise RuntimeError('Neural runtime checksum mismatch')
    target.write_bytes(data)
